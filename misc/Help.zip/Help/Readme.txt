Open the Help.txt file with YahCoLoRiZe. Make any changes and click File->Save
In YahCoLoRiZe, click FIle->Export As Web-Page and export as help.htm

Open help.htm in Notepad++ and perform two global replacements:

1) " --> \"
2) \r\n --> ",\r\n"

Copy paste into Help.cpp and add terminating line: , "\x04"};