Open the Help.txt file with YahCoLoRiZe. Make any changes and click File->Save
In YahCoLoRiZe, click FIle->Export As Web-Page and export as help.htm

Open help.htm in Notepad++ and perform two global replacements:

1) " --> \"
2) \r\n --> ",\r\n"

Add to first line: ={"
Add to last lineing line: ", "\x04"};
Save as editedHtml.txt
Copy paste into Help.cpp
