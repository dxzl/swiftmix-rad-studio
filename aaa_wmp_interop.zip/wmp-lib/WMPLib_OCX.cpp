// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision:   1.96.1.40  $
// File generated on 2/21/2006 9:08:19 PM from Type Library described below.

// ************************************************************************ //
// Type Lib: C:\WINDOWS\system32\wmp.dll
// IID\LCID: {6BF52A50-394A-11D3-B153-00C04F79FAA6}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\system32\stdole2.tlb)
//   (2) v4.0 StdVCL, (C:\WINDOWS\system32\STDVCL40.DLL)
// Errors:
//   Hint: Parameter 'Result' in IWMPEvents.Disconnect changed to 'Result_'
//   Hint: Parameter 'Result' in IWMPEvents.EndOfStream changed to 'Result_'
//   Hint: Parameter 'Result' in _WMPOCXEvents.Disconnect changed to 'Result_'
//   Hint: Parameter 'Result' in _WMPOCXEvents.EndOfStream changed to 'Result_'
//   Hint: Parameter 'Result' in _WMPCoreEvents.Disconnect changed to 'Result_'
//   Hint: Parameter 'Result' in _WMPCoreEvents.EndOfStream changed to 'Result_'
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#include "WMPLib_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmplib_tlb
{



// *********************************************************************//
// OCX PROXY CLASS IMPLEMENTATION
// (The following variables/methods implement the class TWindowsMediaPlayer which
// allows "Windows Media Player ActiveX Control" to be hosted in CBuilder IDE/apps).
// *********************************************************************//
int   TWindowsMediaPlayer::EventDispIDs[51] = {
    0x00001389, 0x000013ED, 0x000013EE, 0x0000138A, 0x000014B5, 0x0000151B,
    0x00001519, 0x0000151A, 0x0000157D, 0x000015E1, 0x00001451, 0x00001452,
    0x00001453, 0x00001454, 0x00001645, 0x000016A9, 0x000016AC, 0x000016AD,
    0x000016AA, 0x000016AB, 0x000016AE, 0x000016AF, 0x000016B0, 0x000016B1,
    0x000016BC, 0x000016B2, 0x000016B3, 0x000016B4, 0x000016BA, 0x000016BB,
    0x000016BD, 0x000016BF, 0x000016BE, 0x00001965, 0x00001966, 0x00001967,
    0x00001968, 0x00001969, 0x0000196A, 0x0000196B, 0x0000196C, 0x0000196D,
    0x0000196E, 0x0000196F, 0x00001970, 0x00001971, 0x00001972, 0x00001973,
    0x00001974, 0x00001975, 0x00001976};

TControlData TWindowsMediaPlayer::CControlData =
{
  // GUID of CoClass and Event Interface of Control
  {0x6BF52A52, 0x394A, 0x11D3,{ 0xB1, 0x53, 0x00, 0xC0, 0x4F, 0x79, 0xFA, 0xA6} }, // CoClass
  {0x6BF52A51, 0x394A, 0x11D3,{ 0xB1, 0x53, 0x00, 0xC0, 0x4F, 0x79, 0xFA, 0xA6} }, // Events

  // Count of Events and array of their DISPIDs
  51, &EventDispIDs,

  // Pointer to Runtime License string
  NULL,  // HRESULT(0x80040111)

  // Flags for OnChanged PropertyNotification
  0x00000000,
  300,// (IDE Version)

  // Count of Font Prop and array of their DISPIDs
  0, NULL,

  // Count of Pict Prop and array of their DISPIDs
  0, NULL,
  0, // Reserved
  0, // Instance count (used internally)
  0, // List of Enum descriptions (internal)
};

GUID     TWindowsMediaPlayer::DEF_CTL_INTF = {0x6C497D62, 0x8919, 0x413C,{ 0x82, 0xDB, 0xE9, 0x35, 0xFB, 0x3E, 0xC5, 0x84} };
TNoParam TWindowsMediaPlayer::OptParam;

static inline void ValidCtrCheck(TWindowsMediaPlayer *)
{
   delete new TWindowsMediaPlayer((TComponent*)(0));
};

void __fastcall TWindowsMediaPlayer::InitControlData(void)
{
  ControlData = &CControlData;
};

void __fastcall TWindowsMediaPlayer::CreateControl(void)
{
  if (!m_OCXIntf)
  {
    _ASSERTE(DefaultDispatch);
    DefaultDispatch->QueryInterface(DEF_CTL_INTF, (LPVOID*)&m_OCXIntf);
  }
};

IWMPPlayer4Disp __fastcall TWindowsMediaPlayer::GetControlInterface(void)
{
  CreateControl();
  return m_OCXIntf;
};

void/*HR*/ __fastcall TWindowsMediaPlayer::close(void)
{
  GetControlInterface().close();
}

void/*HR*/ __fastcall TWindowsMediaPlayer::launchURL(BSTR bstrURL/*[in]*/)
{
  GetControlInterface().launchURL(bstrURL/*[in]*/);
}

Wmplib_tlb::IWMPPlaylistPtr __fastcall TWindowsMediaPlayer::newPlaylist(BSTR bstrName/*[in]*/, 
                                                                        BSTR bstrURL/*[in]*/)
{
  return GetControlInterface().newPlaylist(bstrName/*[in]*/, bstrURL/*[in]*/);
}

Wmplib_tlb::IWMPMediaPtr __fastcall TWindowsMediaPlayer::newMedia(BSTR bstrURL/*[in]*/)
{
  return GetControlInterface().newMedia(bstrURL/*[in]*/);
}

void/*HR*/ __fastcall TWindowsMediaPlayer::openPlayer(BSTR bstrURL/*[in]*/)
{
  GetControlInterface().openPlayer(bstrURL/*[in]*/);
}

Wmplib_tlb::WMPOpenState __fastcall TWindowsMediaPlayer::Get_openState(void)
{
  return GetControlInterface().get_openState();
}

Wmplib_tlb::WMPPlayState __fastcall TWindowsMediaPlayer::Get_playState(void)
{
  return GetControlInterface().get_playState();
}

Wmplib_tlb::IWMPControlsPtr __fastcall TWindowsMediaPlayer::Get_controls(void)
{
  return GetControlInterface().get_controls();
}

Wmplib_tlb::IWMPSettingsPtr __fastcall TWindowsMediaPlayer::Get_settings(void)
{
  return GetControlInterface().get_settings();
}

Wmplib_tlb::IWMPMediaPtr __fastcall TWindowsMediaPlayer::Get_currentMedia(void)
{
  return GetControlInterface().get_currentMedia();
}

void/*HR*/ __fastcall TWindowsMediaPlayer::Set_currentMedia(Wmplib_tlb::IWMPMediaPtr ppMedia/*[in]*/)
{
  GetControlInterface().set_currentMedia(ppMedia/*[in]*/);
}

Wmplib_tlb::IWMPMediaCollectionPtr __fastcall TWindowsMediaPlayer::Get_mediaCollection(void)
{
  return GetControlInterface().get_mediaCollection();
}

Wmplib_tlb::IWMPPlaylistCollectionPtr __fastcall TWindowsMediaPlayer::Get_playlistCollection(void)
{
  return GetControlInterface().get_playlistCollection();
}

Wmplib_tlb::IWMPNetworkPtr __fastcall TWindowsMediaPlayer::Get_network(void)
{
  return GetControlInterface().get_network();
}

Wmplib_tlb::IWMPPlaylistPtr __fastcall TWindowsMediaPlayer::Get_currentPlaylist(void)
{
  return GetControlInterface().get_currentPlaylist();
}

void/*HR*/ __fastcall TWindowsMediaPlayer::Set_currentPlaylist(Wmplib_tlb::IWMPPlaylistPtr ppPL/*[in]*/)
{
  GetControlInterface().set_currentPlaylist(ppPL/*[in]*/);
}

Wmplib_tlb::IWMPCdromCollectionPtr __fastcall TWindowsMediaPlayer::Get_cdromCollection(void)
{
  return GetControlInterface().get_cdromCollection();
}

Wmplib_tlb::IWMPClosedCaptionPtr __fastcall TWindowsMediaPlayer::Get_closedCaption(void)
{
  return GetControlInterface().get_closedCaption();
}

Wmplib_tlb::IWMPErrorPtr __fastcall TWindowsMediaPlayer::Get_Error(void)
{
  return GetControlInterface().get_Error();
}

Wmplib_tlb::IWMPDVDPtr __fastcall TWindowsMediaPlayer::Get_dvd(void)
{
  return GetControlInterface().get_dvd();
}

Wmplib_tlb::IWMPPlayerApplicationPtr __fastcall TWindowsMediaPlayer::Get_playerApplication(void)
{
  return GetControlInterface().get_playerApplication();
}

};     // namespace Wmplib_tlb


// *********************************************************************//
// The Register function is invoked by the IDE when this module is 
// installed in a Package. It provides the list of Components (including
// OCXes) implemented by this module. The following implementation
// informs the IDE of the OCX proxy classes implemented here.
// *********************************************************************//
namespace Wmplib_ocx
{

void __fastcall PACKAGE Register()
{
  // [1]
  TComponentClass classes[] = {
                              __classid(Wmplib_tlb::TWindowsMediaPlayer)
                             };
  RegisterComponents("ActiveX", classes,
                     sizeof(classes)/sizeof(classes[0])-1);
}
};     // namespace Wmplib_ocx
