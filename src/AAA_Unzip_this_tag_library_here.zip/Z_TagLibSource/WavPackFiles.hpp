﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WavPackFiles.pas' rev: 34.00 (Windows)

#ifndef WavpackfilesHPP
#define WavpackfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Apev2Tags.hpp>
#include <Vcl.Dialogs.hpp>

//-- user supplied -----------------------------------------------------------

namespace Wavpackfiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWavPackFile;
struct wavpack_header3;
struct wavpack_header4;
struct fmt_chunk;
struct riff_chunk;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWavPackFile : public Apev2tags::TBaseApeFile
{
	typedef Apev2tags::TBaseApeFile inherited;
	
private:
	int fFormatTag;
	int fVersion;
	System::UnicodeString fEncoder;
	__int64 fSamples;
	__int64 fBSamples;
	int fBits;
	void __fastcall fResetData();
	double __fastcall fGetRatio();
	System::UnicodeString __fastcall fGetChannelMode();
	bool __fastcall _ReadV3(System::Classes::TStream* f);
	bool __fastcall _ReadV4(System::Classes::TStream* f);
	
protected:
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property int FormatTag = {read=fFormatTag, nodefault};
	__property int Version = {read=fVersion, nodefault};
	__property System::UnicodeString ChannelMode = {read=fGetChannelMode};
	__property __int64 Samples = {read=fSamples};
	__property __int64 BSamples = {read=fBSamples};
	__property double Ratio = {read=fGetRatio};
	__property System::UnicodeString Encoder = {read=fEncoder};
	__property int Bits = {read=fBits, nodefault};
public:
	/* TBaseApeFile.Create */ inline __fastcall TWavPackFile() : Apev2tags::TBaseApeFile() { }
	/* TBaseApeFile.Destroy */ inline __fastcall virtual ~TWavPackFile() { }
	
};


struct DECLSPEC_DRECORD wavpack_header3
{
public:
	System::StaticArray<char, 4> ckID;
	unsigned ckSize;
	System::Word version;
	System::Word bits;
	System::Word flags;
	System::Word shift;
	unsigned total_samples;
	unsigned crc;
	unsigned crc2;
	System::StaticArray<char, 4> extension;
	System::Byte extra_bc;
	System::StaticArray<char, 3> extras;
};


struct DECLSPEC_DRECORD wavpack_header4
{
public:
	System::StaticArray<char, 4> ckID;
	unsigned ckSize;
	System::Word version;
	System::Byte track_no;
	System::Byte index_no;
	unsigned total_samples;
	unsigned block_index;
	unsigned block_samples;
	unsigned flags;
	unsigned crc;
};


struct DECLSPEC_DRECORD fmt_chunk
{
public:
	System::Word wformattag;
	System::Word wchannels;
	unsigned dwsamplespersec;
	unsigned dwavgbytespersec;
	System::Word wblockalign;
	System::Word wbitspersample;
};


struct DECLSPEC_DRECORD riff_chunk
{
public:
	System::StaticArray<char, 4> id;
	unsigned size;
};


//-- var, const, procedure ---------------------------------------------------
static const System::Int8 MONO_FLAG_v3 = System::Int8(0x1);
static const System::Int8 FAST_FLAG_v3 = System::Int8(0x2);
static const System::Int8 HIGH_FLAG_v3 = System::Int8(0x10);
static const System::Byte WVC_FLAG_v3 = System::Byte(0x80);
static const System::Word NEW_HIGH_FLAG_v3 = System::Word(0x400);
static const System::Word EXTREME_DECORR_v3 = System::Word(0x8000);
extern DELPHI_PACKAGE System::StaticArray<int, 15> sample_rates;
}	/* namespace Wavpackfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WAVPACKFILES)
using namespace Wavpackfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// WavpackfilesHPP
