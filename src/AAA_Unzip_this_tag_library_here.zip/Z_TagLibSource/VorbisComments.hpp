﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VorbisComments.pas' rev: 34.00 (Windows)

#ifndef VorbiscommentsHPP
#define VorbiscommentsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Vorbiscomments
{
//-- forward type declarations -----------------------------------------------
struct TVorbisHeader;
struct TVorbisIdentification;
class DELPHICLASS TCommentVector;
class DELPHICLASS TVorbisComments;
//-- type declarations -------------------------------------------------------
#pragma pack(push,1)
struct DECLSPEC_DRECORD TVorbisHeader
{
public:
	System::Byte PacketType;
	System::StaticArray<char, 6> ID;
};
#pragma pack(pop)


#pragma pack(push,1)
struct DECLSPEC_DRECORD TVorbisIdentification
{
public:
	System::Byte PacketType;
	System::StaticArray<char, 6> ID;
	unsigned BitstreamVersion;
	System::Byte ChannelMode;
	int SampleRate;
	int BitRateMaximal;
	int BitRateNominal;
	int BitRateMinimal;
	System::Byte BlockSize;
	System::Byte StopFlag;
};
#pragma pack(pop)


#pragma pack(push,4)
class PASCALIMPLEMENTATION TCommentVector : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::AnsiString fFieldName;
	System::UnicodeString fValue;
	System::UnicodeString __fastcall fGetFieldName();
	void __fastcall fSetFieldname(System::UnicodeString aName);
	System::UnicodeString __fastcall fGetValue();
	void __fastcall fSetValue(System::UnicodeString aValue);
	
public:
	__property System::UnicodeString FieldName = {read=fGetFieldName, write=fSetFieldname};
	__property System::UnicodeString Value = {read=fGetValue, write=fSetValue};
	bool __fastcall ReadFromStream(System::Classes::TStream* Source);
	bool __fastcall WriteToStream(System::Classes::TStream* Destination);
public:
	/* TObject.Create */ inline __fastcall TCommentVector() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCommentVector() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TVorbisComments : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TVorbisHeader fHeader;
	System::UTF8String fVendorString;
	System::Contnrs::TObjectList* fCommentVectorList;
	bool fValidComment;
	System::UnicodeString __fastcall fGetPropertyByFieldname(System::UnicodeString aField);
	System::UnicodeString __fastcall fGetTitle();
	System::UnicodeString __fastcall fGetVersion();
	System::UnicodeString __fastcall fGetAlbum();
	System::UnicodeString __fastcall fGetTrackNumber();
	System::UnicodeString __fastcall fGetArtist();
	System::UnicodeString __fastcall fGetPerformer();
	System::UnicodeString __fastcall fGetCopyright();
	System::UnicodeString __fastcall fGetLicense();
	System::UnicodeString __fastcall fGetOrganization();
	System::UnicodeString __fastcall fGetDescription();
	System::UnicodeString __fastcall fGetGenre();
	System::UnicodeString __fastcall fGetDate();
	System::UnicodeString __fastcall fGetLocation();
	System::UnicodeString __fastcall fGetContact();
	System::UnicodeString __fastcall fGetISRC();
	void __fastcall fSetPropertyByFieldname(System::UnicodeString aField, System::UnicodeString aValue);
	void __fastcall fSetTitle(System::UnicodeString value);
	void __fastcall fSetVersion(System::UnicodeString value);
	void __fastcall fSetAlbum(System::UnicodeString value);
	void __fastcall fSetTrackNumber(System::UnicodeString value);
	void __fastcall fSetArtist(System::UnicodeString value);
	void __fastcall fSetPerformer(System::UnicodeString value);
	void __fastcall fSetCopyright(System::UnicodeString value);
	void __fastcall fSetLicense(System::UnicodeString value);
	void __fastcall fSetOrganization(System::UnicodeString value);
	void __fastcall fSetDescription(System::UnicodeString value);
	void __fastcall fSetGenre(System::UnicodeString value);
	void __fastcall fSetDate(System::UnicodeString value);
	void __fastcall fSetLocation(System::UnicodeString value);
	void __fastcall fSetContact(System::UnicodeString value);
	void __fastcall fSetISRC(System::UnicodeString value);
	
public:
	__property bool ValidComment = {read=fValidComment, nodefault};
	__property System::UTF8String VendorString = {read=fVendorString};
	__property System::UnicodeString Title = {read=fGetTitle, write=fSetTitle};
	__property System::UnicodeString Version = {read=fGetVersion, write=fSetVersion};
	__property System::UnicodeString Album = {read=fGetAlbum, write=fSetAlbum};
	__property System::UnicodeString TrackNumber = {read=fGetTrackNumber, write=fSetTrackNumber};
	__property System::UnicodeString Artist = {read=fGetArtist, write=fSetArtist};
	__property System::UnicodeString Performer = {read=fGetPerformer, write=fSetPerformer};
	__property System::UnicodeString Copyright = {read=fGetCopyright, write=fSetCopyright};
	__property System::UnicodeString License = {read=fGetLicense, write=fSetLicense};
	__property System::UnicodeString Organization = {read=fGetOrganization, write=fSetOrganization};
	__property System::UnicodeString Description = {read=fGetDescription, write=fSetDescription};
	__property System::UnicodeString Genre = {read=fGetGenre, write=fSetGenre};
	__property System::UnicodeString Date = {read=fGetDate, write=fSetDate};
	__property System::UnicodeString Location = {read=fGetLocation, write=fSetLocation};
	__property System::UnicodeString Contact = {read=fGetContact, write=fSetContact};
	__property System::UnicodeString ISRC = {read=fGetISRC, write=fSetISRC};
	__fastcall TVorbisComments();
	__fastcall virtual ~TVorbisComments();
	void __fastcall Clear();
	bool __fastcall ReadFromStream(System::Classes::TStream* Source, int Size, bool SkipHeader = false);
	bool __fastcall WriteToStream(System::Classes::TStream* Destination, bool SkipHeader = false);
	int __fastcall GetSizeInStream();
	System::UnicodeString __fastcall GetPropertyByFieldname(System::UnicodeString aField);
	bool __fastcall SetPropertyByFieldname(System::UnicodeString aField, System::UnicodeString aValue);
	void __fastcall GetAllFields(System::Classes::TStrings* Target);
	System::UnicodeString __fastcall GetPropertyByIndex(int aIndex);
	bool __fastcall SetPropertyByIndex(int aIndex, System::UnicodeString aValue);
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
#define VORBIS_ID L"vorbis"
}	/* namespace Vorbiscomments */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_VORBISCOMMENTS)
using namespace Vorbiscomments;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VorbiscommentsHPP
