﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AudioFileBasics.pas' rev: 34.00 (Windows)

#ifndef AudiofilebasicsHPP
#define AudiofilebasicsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>

//-- user supplied -----------------------------------------------------------

namespace Audiofilebasics
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TBaseAudioFile;
//-- type declarations -------------------------------------------------------
typedef System::Classes::TFileStream TAudioFileStream;

enum DECLSPEC_DENUM TAudioError : unsigned char { FileErr_None, FileErr_NoFile, FileErr_FileCreate, FileErr_FileOpenR, FileErr_FileOpenRW, FileErr_ReadOnly, MP3ERR_StreamRead, MP3ERR_StreamWrite, Mp3ERR_Cache, Mp3ERR_NoTag, MP3ERR_Invalid_Header, Mp3ERR_Compression, Mp3ERR_Unclassified, MP3ERR_NoMpegFrame, OVErr_InvalidFirstPageHeader, OVErr_InvalidFirstPage, OVErr_InvalidSecondPageHeader, OVErr_InvalidSecondPage, OVErr_CommentTooLarge, OVErr_BackupFailed, OVErr_DeleteBackupFailed, OVErr_RemovingNotSupported, FlacErr_InvalidFlacFile, FlacErr_MetaDataTooLarge, FlacErr_BackupFailed, FlacErr_DeleteBackupFailed, FlacErr_RemovingNotSupported, ApeErr_InvalidApeFile, ApeErr_InvalidTag, ApeErr_NoTag, WmaErr_WritingNotSupported, WavErr_WritingNotSupported, 
	M4AErr_64BitNotSupported, M4aErr_Invalid_TopLevelAtom, M4aErr_Invalid_UDTA, M4aErr_Invalid_METAVersion, M4aErr_Invalid_MDHD, M4aErr_Invalid_STSD, M4aErr_Invalid_STCO, M4aErr_Invalid_STBL, M4aErr_Invalid_TRAK, M4aErr_Invalid_MDIA, M4aErr_Invalid_MINF, M4aErr_Invalid_MOOV, M4aErr_Invalid_DuplicateUDTA, M4aErr_Invalid_DuplicateTRAK, M4aErr_RemovingNotSupported, FileErr_NotSupportedFileType };

class PASCALIMPLEMENTATION TBaseAudioFile : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	__int64 fFileSize;
	int fDuration;
	int fBitrate;
	int fSamplerate;
	int fChannels;
	bool fValid;
	virtual __int64 __fastcall fGetFileSize() = 0 ;
	virtual int __fastcall fGetDuration() = 0 ;
	virtual int __fastcall fGetBitrate() = 0 ;
	virtual int __fastcall fGetSamplerate() = 0 ;
	virtual int __fastcall fGetChannels() = 0 ;
	virtual bool __fastcall fGetValid() = 0 ;
	virtual System::UnicodeString __fastcall fGetTitle() = 0 ;
	virtual System::UnicodeString __fastcall fGetArtist() = 0 ;
	virtual System::UnicodeString __fastcall fGetAlbum() = 0 ;
	virtual System::UnicodeString __fastcall fGetYear() = 0 ;
	virtual System::UnicodeString __fastcall fGetTrack() = 0 ;
	virtual System::UnicodeString __fastcall fGetGenre() = 0 ;
	virtual void __fastcall fSetTitle(System::UnicodeString aValue) = 0 ;
	virtual void __fastcall fSetArtist(System::UnicodeString aValue) = 0 ;
	virtual void __fastcall fSetAlbum(System::UnicodeString aValue) = 0 ;
	virtual void __fastcall fSetYear(System::UnicodeString aValue) = 0 ;
	virtual void __fastcall fSetTrack(System::UnicodeString aValue) = 0 ;
	virtual void __fastcall fSetGenre(System::UnicodeString aValue) = 0 ;
	
public:
	__property bool Valid = {read=fGetValid, nodefault};
	__property __int64 FileSize = {read=fGetFileSize};
	__property int Duration = {read=fGetDuration, nodefault};
	__property int Bitrate = {read=fGetBitrate, nodefault};
	__property int Samplerate = {read=fGetSamplerate, nodefault};
	__property int Channels = {read=fGetChannels, nodefault};
	__property System::UnicodeString Title = {read=fGetTitle, write=fSetTitle};
	__property System::UnicodeString Artist = {read=fGetArtist, write=fSetArtist};
	__property System::UnicodeString Album = {read=fGetAlbum, write=fSetAlbum};
	__property System::UnicodeString Year = {read=fGetYear, write=fSetYear};
	__property System::UnicodeString Track = {read=fGetTrack, write=fSetTrack};
	__property System::UnicodeString Genre = {read=fGetGenre, write=fSetGenre};
	virtual TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename) = 0 ;
	virtual TAudioError __fastcall WriteToFile(System::UnicodeString aFilename) = 0 ;
	virtual TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename) = 0 ;
public:
	/* TObject.Create */ inline __fastcall TBaseAudioFile() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TBaseAudioFile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::UnicodeString __fastcall ConvertUTF8ToString(System::UTF8String aUTF8String);
extern DELPHI_PACKAGE System::UTF8String __fastcall ConvertStringToUTF8(System::UnicodeString aString);
extern DELPHI_PACKAGE bool __fastcall AudioFileExists(System::UnicodeString aString);
}	/* namespace Audiofilebasics */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_AUDIOFILEBASICS)
using namespace Audiofilebasics;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AudiofilebasicsHPP
