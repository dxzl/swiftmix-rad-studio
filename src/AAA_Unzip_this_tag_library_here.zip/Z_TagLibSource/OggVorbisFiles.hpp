﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'OggVorbisFiles.pas' rev: 34.00 (Windows)

#ifndef OggvorbisfilesHPP
#define OggvorbisfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <AudioFileBasics.hpp>
#include <VorbisComments.hpp>
#include <Id3Basics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Oggvorbisfiles
{
//-- forward type declarations -----------------------------------------------
struct TOggHeader;
class DELPHICLASS TOggPage;
class DELPHICLASS TFirstOggVorbisPage;
class DELPHICLASS TSecondOggVorbisPage;
class DELPHICLASS TOggVorbisFile;
//-- type declarations -------------------------------------------------------
typedef System::DynamicArray<System::Byte> TPageBuffer;

typedef System::DynamicArray<System::Byte> TLacingValues;

#pragma pack(push,1)
struct DECLSPEC_DRECORD TOggHeader
{
public:
	System::StaticArray<char, 4> ID;
	System::Byte StreamVersion;
	System::Byte TypeFlag;
	__int64 AbsolutePosition;
	int Serial;
	int PageNumber;
	unsigned Checksum;
	System::Byte Segments;
};
#pragma pack(pop)


class PASCALIMPLEMENTATION TOggPage : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TOggHeader fHeader;
	TLacingValues fLacingValues;
	bool fValidHeader;
	bool fValidPage;
	__int64 fPositionInStream;
	
public:
	__property bool ValidHeader = {read=fValidHeader, nodefault};
	__property bool ValidPage = {read=fValidPage, nodefault};
	void __fastcall ReadHeader(System::Classes::TStream* Source);
	void __fastcall WriteHeader(System::Classes::TStream* Destination);
public:
	/* TObject.Create */ inline __fastcall TOggPage() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOggPage() { }
	
};


class PASCALIMPLEMENTATION TFirstOggVorbisPage : public TOggPage
{
	typedef TOggPage inherited;
	
private:
	Vorbiscomments::TVorbisIdentification fVorbisIdentification;
	
public:
	Audiofilebasics::TAudioError __fastcall ReadPage(System::Classes::TStream* Source);
	void __fastcall ClearPage();
public:
	/* TObject.Create */ inline __fastcall TFirstOggVorbisPage() : TOggPage() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TFirstOggVorbisPage() { }
	
};


class PASCALIMPLEMENTATION TSecondOggVorbisPage : public TOggPage
{
	typedef TOggPage inherited;
	
private:
	int fCommentSize;
	TPageBuffer RestOfPage;
	TLacingValues fLacingValuesRestOfPage;
	
public:
	Vorbiscomments::TVorbisComments* Comments;
	__fastcall TSecondOggVorbisPage();
	__fastcall virtual ~TSecondOggVorbisPage();
	Audiofilebasics::TAudioError __fastcall ReadPage(System::Classes::TStream* Source);
	Audiofilebasics::TAudioError __fastcall ReadPageForRewrite(System::Classes::TStream* Source);
	void __fastcall ClearPage();
};


class PASCALIMPLEMENTATION TOggVorbisFile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	int fMaxSamples;
	System::Word fBitRateNominal;
	bool fUsePadding;
	int __fastcall GetMaxSample(System::Classes::TStream* aStream);
	System::UnicodeString __fastcall fGetVersion();
	System::UnicodeString __fastcall fGetPerformer();
	System::UnicodeString __fastcall fGetCopyright();
	System::UnicodeString __fastcall fGetLicense();
	System::UnicodeString __fastcall fGetOrganization();
	System::UnicodeString __fastcall fGetDescription();
	System::UnicodeString __fastcall fGetLocation();
	System::UnicodeString __fastcall fGetContact();
	System::UnicodeString __fastcall fGetISRC();
	void __fastcall fSetVersion(System::UnicodeString value);
	void __fastcall fSetPerformer(System::UnicodeString value);
	void __fastcall fSetCopyright(System::UnicodeString value);
	void __fastcall fSetLicense(System::UnicodeString value);
	void __fastcall fSetOrganization(System::UnicodeString value);
	void __fastcall fSetDescription(System::UnicodeString value);
	void __fastcall fSetLocation(System::UnicodeString value);
	void __fastcall fSetContact(System::UnicodeString value);
	void __fastcall fSetISRC(System::UnicodeString value);
	Audiofilebasics::TAudioError __fastcall ReadFirstTwoPages(System::Classes::TStream* source, TFirstOggVorbisPage* first, TSecondOggVorbisPage* second);
	Audiofilebasics::TAudioError __fastcall BackUpRestOfFile(System::Classes::TStream* source, System::UnicodeString BackUpFilename);
	Audiofilebasics::TAudioError __fastcall AppendBackup(System::Classes::TStream* Destination, System::UnicodeString BackUpFilename);
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetGenre();
	virtual void __fastcall fSetTitle(System::UnicodeString value);
	virtual void __fastcall fSetAlbum(System::UnicodeString value);
	virtual void __fastcall fSetTrack(System::UnicodeString value);
	virtual void __fastcall fSetArtist(System::UnicodeString value);
	virtual void __fastcall fSetGenre(System::UnicodeString value);
	virtual void __fastcall fSetYear(System::UnicodeString value);
	
public:
	TFirstOggVorbisPage* FirstOggVorbisPage;
	TSecondOggVorbisPage* SecondOggVorbisPage;
	__property int Samples = {read=fMaxSamples, nodefault};
	__property System::Word BitRateNominal = {read=fBitRateNominal, nodefault};
	__property bool UsePadding = {read=fUsePadding, write=fUsePadding, nodefault};
	__property System::UnicodeString Version = {read=fGetVersion, write=fSetVersion};
	__property System::UnicodeString Performer = {read=fGetPerformer, write=fSetPerformer};
	__property System::UnicodeString Copyright = {read=fGetCopyright, write=fSetCopyright};
	__property System::UnicodeString License = {read=fGetLicense, write=fSetLicense};
	__property System::UnicodeString Organization = {read=fGetOrganization, write=fSetOrganization};
	__property System::UnicodeString Description = {read=fGetDescription, write=fSetDescription};
	__property System::UnicodeString Location = {read=fGetLocation, write=fSetLocation};
	__property System::UnicodeString Contact = {read=fGetContact, write=fSetContact};
	__property System::UnicodeString ISRC = {read=fGetISRC, write=fSetISRC};
	__fastcall TOggVorbisFile();
	__fastcall virtual ~TOggVorbisFile();
	void __fastcall ClearData();
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
	System::UnicodeString __fastcall GetPropertyByFieldname(System::UnicodeString aField);
	bool __fastcall SetPropertyByFieldname(System::UnicodeString aField, System::UnicodeString aValue);
	void __fastcall GetAllFields(System::Classes::TStrings* Target);
	System::UnicodeString __fastcall GetPropertyByIndex(int aIndex);
	bool __fastcall SetPropertyByIndex(int aIndex, System::UnicodeString aValue);
};


//-- var, const, procedure ---------------------------------------------------
#define OGG_PAGE_ID L"OggS"
extern DELPHI_PACKAGE System::StaticArray<unsigned, 256> CRC_TABLE;
}	/* namespace Oggvorbisfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_OGGVORBISFILES)
using namespace Oggvorbisfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OggvorbisfilesHPP
