﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WavFiles.pas' rev: 34.00 (Windows)

#ifndef WavfilesHPP
#define WavfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>
#include <AudioFileBasics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Wavfiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS Twavfile;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION Twavfile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	void __fastcall fResetData();
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual void __fastcall fSetTitle(System::UnicodeString aValue);
	virtual void __fastcall fSetArtist(System::UnicodeString aValue);
	virtual void __fastcall fSetAlbum(System::UnicodeString aValue);
	virtual void __fastcall fSetYear(System::UnicodeString aValue);
	virtual void __fastcall fSetTrack(System::UnicodeString aValue);
	virtual void __fastcall fSetGenre(System::UnicodeString aValue);
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetGenre();
	
public:
	__fastcall Twavfile();
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~Twavfile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Wavfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WAVFILES)
using namespace Wavfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// WavfilesHPP
