﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'MonkeyFiles.pas' rev: 34.00 (Windows)

#ifndef MonkeyfilesHPP
#define MonkeyfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Apev2Tags.hpp>
#include <Vcl.Dialogs.hpp>

//-- user supplied -----------------------------------------------------------

namespace Monkeyfiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TMonkeyFile;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 7> Monkeyfiles__1;

typedef System::StaticArray<System::UnicodeString, 3> Monkeyfiles__2;

class PASCALIMPLEMENTATION TMonkeyFile : public Apev2tags::TBaseApeFile
{
	typedef Apev2tags::TBaseApeFile inherited;
	
private:
	int fVersion;
	System::UnicodeString fVersionStr;
	unsigned fPeakLevel;
	double fPeakLevelRatio;
	__int64 fTotalSamples;
	int fCompressionMode;
	System::UnicodeString fCompressionModeStr;
	int fFormatFlags;
	bool fHasPeakLevel;
	bool fHasSeekElements;
	bool fWavNotStored;
	int fBits;
	void __fastcall fResetData();
	System::UnicodeString __fastcall fGetVersionStr();
	
protected:
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property int Version = {read=fVersion, nodefault};
	__property System::UnicodeString VersionStr = {read=fGetVersionStr};
	__property unsigned PeakLevel = {read=fPeakLevel, nodefault};
	__property double PeakLevelRatio = {read=fPeakLevelRatio};
	__property __int64 TotalSamples = {read=fTotalSamples};
	__property int CompressionMode = {read=fCompressionMode, nodefault};
	__property System::UnicodeString CompressionModeStr = {read=fCompressionModeStr};
	__property int FormatFlags = {read=fFormatFlags, nodefault};
	__property bool HasPeakLevel = {read=fHasPeakLevel, nodefault};
	__property bool HasSeekElements = {read=fHasSeekElements, nodefault};
	__property bool WavNotStored = {read=fWavNotStored, nodefault};
	__property int Bits = {read=fBits, nodefault};
public:
	/* TBaseApeFile.Create */ inline __fastcall TMonkeyFile() : Apev2tags::TBaseApeFile() { }
	/* TBaseApeFile.Destroy */ inline __fastcall virtual ~TMonkeyFile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const System::Word MONKEY_COMPRESSION_FAST = System::Word(0x3e8);
static const System::Word MONKEY_COMPRESSION_NORMAL = System::Word(0x7d0);
static const System::Word MONKEY_COMPRESSION_HIGH = System::Word(0xbb8);
static const System::Word MONKEY_COMPRESSION_EXTRA_HIGH = System::Word(0xfa0);
static const System::Word MONKEY_COMPRESSION_INSANE = System::Word(0x1388);
static const System::Word MONKEY_COMPRESSION_BRAINDEAD = System::Word(0x1770);
extern DELPHI_PACKAGE Monkeyfiles__1 MONKEY_COMPRESSION;
static const System::Int8 MONKEY_FLAG_8_BIT = System::Int8(0x1);
static const System::Int8 MONKEY_FLAG_CRC = System::Int8(0x2);
static const System::Int8 MONKEY_FLAG_PEAK_LEVEL = System::Int8(0x4);
static const System::Int8 MONKEY_FLAG_24_BIT = System::Int8(0x8);
static const System::Int8 MONKEY_FLAG_SEEK_ELEMENTS = System::Int8(0x10);
static const System::Int8 MONKEY_FLAG_WAV_NOT_STORED = System::Int8(0x20);
extern DELPHI_PACKAGE Monkeyfiles__2 MONKEY_MODE;
}	/* namespace Monkeyfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_MONKEYFILES)
using namespace Monkeyfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MonkeyfilesHPP
