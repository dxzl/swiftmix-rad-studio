﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Mp3FileUtils.pas' rev: 34.00 (Windows)

#ifndef Mp3fileutilsHPP
#define Mp3fileutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Winapi.Windows.hpp>
#include <System.Contnrs.hpp>
#include <Vcl.Dialogs.hpp>
#include <U_CharCode.hpp>
#include <System.Types.hpp>
#include <ID3v2Frames.hpp>

//-- user supplied -----------------------------------------------------------

namespace Mp3fileutils
{
//-- forward type declarations -----------------------------------------------
struct TID3Version;
struct TID3v1Structure;
class DELPHICLASS TID3v1Tag;
struct TID3v2Header;
class DELPHICLASS TID3v2Tag;
struct TMpegHeader;
struct TXingHeader;
class DELPHICLASS TMpegInfo;
//-- type declarations -------------------------------------------------------
typedef System::Classes::TFileStream TMPFUFileStream;

typedef System::DynamicArray<System::Byte> TBuffer;

enum DECLSPEC_DENUM TMP3Error : unsigned char { MP3ERR_None, MP3ERR_NoFile, MP3ERR_FOpenCrt, MP3ERR_FOpenR, MP3ERR_FOpenRW, MP3ERR_FOpenW, MP3ERR_SRead, MP3ERR_SWrite, ID3ERR_Cache, ID3ERR_NoTag, ID3ERR_Invalid_Header, ID3ERR_Compression, ID3ERR_Unclassified, MPEGERR_NoFrame };

struct DECLSPEC_DRECORD TID3Version
{
public:
	System::Byte Major;
	System::Byte Minor;
};


typedef System::SmallString<4> String4;

typedef System::SmallString<30> String30;

struct DECLSPEC_DRECORD TID3v1Structure
{
public:
	System::StaticArray<char, 3> ID;
	System::StaticArray<char, 30> Title;
	System::StaticArray<char, 30> Artist;
	System::StaticArray<char, 30> Album;
	System::StaticArray<char, 4> Year;
	System::StaticArray<char, 30> Comment;
	System::Byte Genre;
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TID3v1Tag : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	String30 FTitle;
	String30 FArtist;
	String30 FAlbum;
	String30 FComment;
	System::Byte FTrack;
	String4 FYear;
	System::Byte FGenre;
	bool FExists;
	System::Byte FVersion;
	bool fAutoCorrectCodepage;
	U_charcode::TCodePage FCharCode;
	System::UnicodeString __fastcall GetConvertedUnicodeText(String30 &Value);
	System::UnicodeString __fastcall GetTitle();
	System::UnicodeString __fastcall GetArtist();
	System::UnicodeString __fastcall GetAlbum();
	System::UnicodeString __fastcall GetComment();
	System::UnicodeString __fastcall GetGenre();
	System::UnicodeString __fastcall GetTrack();
	String4 __fastcall GetYear();
	String30 __fastcall SetString30(System::UnicodeString value);
	void __fastcall SetTitle(System::UnicodeString Value);
	void __fastcall SetArtist(System::UnicodeString Value);
	void __fastcall SetAlbum(System::UnicodeString Value);
	void __fastcall SetGenre(System::UnicodeString Value);
	void __fastcall SetYear(String4 &Value);
	void __fastcall SetComment(System::UnicodeString Value);
	void __fastcall SetTrack(System::UnicodeString Value);
	
public:
	__fastcall TID3v1Tag();
	__fastcall virtual ~TID3v1Tag();
	__property bool TagExists = {read=FExists, nodefault};
	__property bool Exists = {read=FExists, nodefault};
	__property System::Byte Version = {read=FVersion, nodefault};
	__property System::UnicodeString Title = {read=GetTitle, write=SetTitle};
	__property System::UnicodeString Artist = {read=GetArtist, write=SetArtist};
	__property System::UnicodeString Album = {read=GetAlbum, write=SetAlbum};
	__property System::UnicodeString Genre = {read=GetGenre, write=SetGenre};
	__property System::UnicodeString Track = {read=GetTrack, write=SetTrack};
	__property String4 Year = {read=GetYear, write=SetYear};
	__property System::UnicodeString Comment = {read=GetComment, write=SetComment};
	__property U_charcode::TCodePage CharCode = {read=FCharCode, write=FCharCode};
	__property bool AutoCorrectCodepage = {read=fAutoCorrectCodepage, write=fAutoCorrectCodepage, nodefault};
	void __fastcall Clear();
	TMP3Error __fastcall ReadFromStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall WriteToStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall RemoveFromStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall ReadFromFile(System::UnicodeString Filename);
	TMP3Error __fastcall WriteToFile(System::UnicodeString Filename);
	TMP3Error __fastcall RemoveFromFile(System::UnicodeString Filename);
};

#pragma pack(pop)

typedef System::StaticArray<System::Byte, 4> TInt28;

struct DECLSPEC_DRECORD TID3v2Header
{
public:
	System::StaticArray<char, 3> ID;
	System::Byte Version;
	System::Byte Revision;
	System::Byte Flags;
	TInt28 TagSize;
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TID3v2Tag : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::Contnrs::TObjectList* Frames;
	bool fExists;
	TID3Version fVersion;
	bool fFlgUnsynch;
	bool fFlgCompression;
	bool fFlgExtended;
	bool fFlgExperimental;
	bool fFlgFooterPresent;
	bool fFlgUnknown;
	unsigned fPaddingSize;
	unsigned fTagSize;
	unsigned fDataSize;
	bool fUsePadding;
	bool fUseClusteredPadding;
	System::UnicodeString fFilename;
	bool fAlwaysWriteUnicode;
	bool fAutoCorrectCodepage;
	U_charcode::TCodePage fCharCode;
	System::AnsiString __fastcall GetFrameIDString(Id3v2frames::TFrameIDs ID);
	int __fastcall GetFrameIndex(Id3v2frames::TFrameIDs ID);
	int __fastcall GetUserTextFrameIndex(System::UnicodeString aDescription);
	int __fastcall GetDescribedTextFrameIndex(Id3v2frames::TFrameIDs ID, System::AnsiString Language, System::UnicodeString Description);
	int __fastcall GetPictureFrameIndex(System::UnicodeString aDescription);
	int __fastcall GetUserDefinedURLFrameIndex(System::UnicodeString Description);
	int __fastcall GetPopularimaterFrameIndex(System::AnsiString aEMail);
	int __fastcall GetPrivateFrameIndex(System::AnsiString aOwnerID);
	System::UnicodeString __fastcall GetDescribedTextFrame(Id3v2frames::TFrameIDs ID, System::AnsiString Language, System::UnicodeString Description);
	void __fastcall SetDescribedTextFrame(Id3v2frames::TFrameIDs ID, System::AnsiString Language, System::UnicodeString Description, System::UnicodeString Value);
	TMP3Error __fastcall ReadFrames(int From, System::Classes::TStream* Stream);
	TMP3Error __fastcall ReadHeader(System::Classes::TStream* Stream);
	void __fastcall SyncStream(System::Classes::TStream* Source, System::Classes::TStream* Target);
	System::UnicodeString __fastcall GetTitle();
	System::UnicodeString __fastcall GetArtist();
	System::UnicodeString __fastcall GetAlbum();
	System::UnicodeString __fastcall ParseID3v2Genre(System::UnicodeString value);
	System::UnicodeString __fastcall GetGenre();
	System::UnicodeString __fastcall GetTrack();
	System::UnicodeString __fastcall GetYear();
	System::UnicodeString __fastcall GetStandardComment();
	System::UnicodeString __fastcall GetStandardLyrics();
	System::UnicodeString __fastcall GetComposer();
	System::UnicodeString __fastcall GetOriginalArtist();
	System::UnicodeString __fastcall GetCopyright();
	System::UnicodeString __fastcall GetEncodedBy();
	System::UnicodeString __fastcall GetLanguages();
	System::UnicodeString __fastcall GetSoftwareSettings();
	System::UnicodeString __fastcall GetMediatype();
	System::UnicodeString __fastcall Getid3Length();
	System::UnicodeString __fastcall GetPublisher();
	System::UnicodeString __fastcall GetOriginalFilename();
	System::UnicodeString __fastcall GetOriginalLyricist();
	System::UnicodeString __fastcall GetOriginalReleaseYear();
	System::UnicodeString __fastcall GetOriginalAlbumTitel();
	void __fastcall SetTitle(System::UnicodeString Value);
	void __fastcall SetArtist(System::UnicodeString Value);
	void __fastcall SetAlbum(System::UnicodeString Value);
	System::UnicodeString __fastcall BuildID3v2Genre(System::UnicodeString value);
	void __fastcall SetGenre(System::UnicodeString Value);
	void __fastcall SetTrack(System::UnicodeString Value);
	void __fastcall SetYear(System::UnicodeString Value);
	void __fastcall SetStandardComment(System::UnicodeString Value);
	void __fastcall SetStandardLyrics(System::UnicodeString Value);
	void __fastcall SetComposer(System::UnicodeString Value);
	void __fastcall SetOriginalArtist(System::UnicodeString Value);
	void __fastcall SetCopyright(System::UnicodeString Value);
	void __fastcall SetEncodedBy(System::UnicodeString Value);
	void __fastcall SetLanguages(System::UnicodeString Value);
	void __fastcall SetSoftwareSettings(System::UnicodeString Value);
	void __fastcall SetMediatype(System::UnicodeString Value);
	void __fastcall Setid3Length(System::UnicodeString Value);
	void __fastcall SetPublisher(System::UnicodeString Value);
	void __fastcall SetOriginalFilename(System::UnicodeString Value);
	void __fastcall SetOriginalLyricist(System::UnicodeString Value);
	void __fastcall SetOriginalReleaseYear(System::UnicodeString Value);
	void __fastcall SetOriginalAlbumTitel(System::UnicodeString Value);
	System::AnsiString __fastcall GetStandardUserDefinedURL();
	void __fastcall SetStandardUserDefinedURL(System::AnsiString Value);
	System::Byte __fastcall GetArbitraryRating();
	void __fastcall SetArbitraryRating(System::Byte Value);
	unsigned __fastcall GetArbitraryPersonalPlayCounter();
	void __fastcall SetArbitraryPersonalPlayCounter(unsigned Value);
	void __fastcall SetCharCode(const U_charcode::TCodePage &Value);
	void __fastcall SetAutoCorrectCodepage(bool Value);
	
public:
	__fastcall TID3v2Tag();
	__fastcall virtual ~TID3v2Tag();
	__property System::UnicodeString Title = {read=GetTitle, write=SetTitle};
	__property System::UnicodeString Artist = {read=GetArtist, write=SetArtist};
	__property System::UnicodeString Album = {read=GetAlbum, write=SetAlbum};
	__property System::UnicodeString Genre = {read=GetGenre, write=SetGenre};
	__property System::UnicodeString Track = {read=GetTrack, write=SetTrack};
	__property System::UnicodeString Year = {read=GetYear, write=SetYear};
	__property System::UnicodeString Comment = {read=GetStandardComment, write=SetStandardComment};
	__property System::UnicodeString Lyrics = {read=GetStandardLyrics, write=SetStandardLyrics};
	__property System::AnsiString URL = {read=GetStandardUserDefinedURL, write=SetStandardUserDefinedURL};
	__property System::Byte Rating = {read=GetArbitraryRating, write=SetArbitraryRating, nodefault};
	__property unsigned PlayCounter = {read=GetArbitraryPersonalPlayCounter, write=SetArbitraryPersonalPlayCounter, nodefault};
	__property System::UnicodeString Composer = {read=GetComposer, write=SetComposer};
	__property System::UnicodeString OriginalArtist = {read=GetOriginalArtist, write=SetOriginalArtist};
	__property System::UnicodeString Copyright = {read=GetCopyright, write=SetCopyright};
	__property System::UnicodeString EncodedBy = {read=GetEncodedBy, write=SetEncodedBy};
	__property System::UnicodeString Languages = {read=GetLanguages, write=SetLanguages};
	__property System::UnicodeString SoftwareSettings = {read=GetSoftwareSettings, write=SetSoftwareSettings};
	__property System::UnicodeString Mediatype = {read=GetMediatype, write=SetMediatype};
	__property System::UnicodeString id3Length = {read=Getid3Length, write=Setid3Length};
	__property System::UnicodeString Publisher = {read=GetPublisher, write=SetPublisher};
	__property System::UnicodeString OriginalFilename = {read=GetOriginalFilename, write=SetOriginalFilename};
	__property System::UnicodeString OriginalLyricist = {read=GetOriginalLyricist, write=SetOriginalLyricist};
	__property System::UnicodeString OriginalReleaseYear = {read=GetOriginalReleaseYear, write=SetOriginalReleaseYear};
	__property System::UnicodeString OriginalAlbumTitel = {read=GetOriginalAlbumTitel, write=SetOriginalAlbumTitel};
	__property bool FlgUnsynch = {read=fFlgUnsynch, write=fFlgUnsynch, nodefault};
	__property bool FlgCompression = {read=fFlgCompression, nodefault};
	__property bool FlgExtended = {read=fFlgExtended, nodefault};
	__property bool FlgExperimental = {read=fFlgExperimental, nodefault};
	__property bool FlgFooterPresent = {read=fFlgFooterPresent, nodefault};
	__property bool FlgUnknown = {read=fFlgUnknown, nodefault};
	__property unsigned Size = {read=fTagSize, nodefault};
	__property bool Exists = {read=fExists, nodefault};
	__property bool TagExists = {read=fExists, nodefault};
	__property unsigned Padding = {read=fPaddingSize, nodefault};
	__property unsigned PaddingSize = {read=fPaddingSize, nodefault};
	__property TID3Version Version = {read=fVersion};
	__property bool UsePadding = {read=fUsePadding, write=fUsePadding, nodefault};
	__property bool UseClusteredPadding = {read=fUseClusteredPadding, write=fUseClusteredPadding, nodefault};
	__property bool AlwaysWriteUnicode = {read=fAlwaysWriteUnicode, write=fAlwaysWriteUnicode, nodefault};
	__property U_charcode::TCodePage CharCode = {read=fCharCode, write=SetCharCode};
	__property bool AutoCorrectCodepage = {read=fAutoCorrectCodepage, write=SetAutoCorrectCodepage, nodefault};
	TMP3Error __fastcall ReadFromStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall WriteToStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall RemoveFromStream(System::Classes::TStream* Stream);
	TMP3Error __fastcall ReadFromFile(System::UnicodeString Filename);
	TMP3Error __fastcall WriteToFile(System::UnicodeString Filename);
	TMP3Error __fastcall RemoveFromFile(System::UnicodeString Filename);
	void __fastcall Clear();
	System::UnicodeString __fastcall GetText(Id3v2frames::TFrameIDs FrameID);
	void __fastcall SetText(Id3v2frames::TFrameIDs FrameID, System::UnicodeString Value);
	System::UnicodeString __fastcall GetUserText(System::UnicodeString Description);
	void __fastcall SetUserText(System::UnicodeString Description, System::UnicodeString Value);
	System::AnsiString __fastcall GetURL(Id3v2frames::TFrameIDs FrameID);
	void __fastcall SetURL(Id3v2frames::TFrameIDs FrameID, System::AnsiString Value);
	void __fastcall SetExtendedComment(System::AnsiString Language, System::UnicodeString Description, System::UnicodeString value);
	System::UnicodeString __fastcall GetExtendedComment(System::AnsiString Language, System::UnicodeString Description);
	void __fastcall SetLyrics(System::AnsiString Language, System::UnicodeString Description, System::UnicodeString value);
	System::UnicodeString __fastcall GetLyrics(System::AnsiString Language, System::UnicodeString Description);
	System::AnsiString __fastcall GetPicture(System::Classes::TStream* stream, System::UnicodeString Description);
	void __fastcall SetPicture(System::AnsiString MimeTyp, System::Byte PicType, System::UnicodeString Description, System::Classes::TStream* stream);
	System::AnsiString __fastcall GetUserDefinedURL(System::UnicodeString Description);
	void __fastcall SetUserDefinedURL(System::UnicodeString Description, System::AnsiString Value);
	System::Byte __fastcall GetRating(System::AnsiString aEMail);
	unsigned __fastcall GetPersonalPlayCounter(System::AnsiString aEMail);
	void __fastcall SetRatingAndCounter(System::AnsiString aEMail, int aRating, int aCounter);
	bool __fastcall GetPrivateFrame(System::AnsiString aOwnerID, System::Classes::TStream* Content);
	void __fastcall SetPrivateFrame(System::AnsiString aOwnerID, System::Classes::TStream* Content);
	System::Contnrs::TObjectList* __fastcall GetAllFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllTextFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllUserTextFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllCommentFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllLyricFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllUserDefinedURLFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllPictureFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllPopularimeterFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllURLFrames()/* overload */;
	System::Contnrs::TObjectList* __fastcall GetAllPrivateFrames()/* overload */;
	void __fastcall GetAllFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllTextFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllUserTextFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllCommentFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllLyricFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllUserDefinedURLFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllPictureFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllPopularimeterFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllURLFrames(System::Contnrs::TObjectList* aList)/* overload */;
	void __fastcall GetAllPrivateFrames(System::Contnrs::TObjectList* aList)/* overload */;
	bool __fastcall ValidNewCommentFrame(System::AnsiString Language, System::UnicodeString Description);
	bool __fastcall ValidNewLyricFrame(System::AnsiString Language, System::UnicodeString Description);
	bool __fastcall ValidNewPictureFrame(System::UnicodeString Description);
	bool __fastcall ValidNewUserDefUrlFrame(System::UnicodeString Description);
	bool __fastcall ValidNewPopularimeterFrame(System::AnsiString EMail);
	System::Classes::TList* __fastcall GetAllowedTextFrames();
	System::Classes::TList* __fastcall GetAllowedURLFrames();
	Id3v2frames::TID3v2Frame* __fastcall AddFrame(Id3v2frames::TFrameIDs aID);
	void __fastcall DeleteFrame(Id3v2frames::TID3v2Frame* aFrame);
};

#pragma pack(pop)

struct DECLSPEC_DRECORD TMpegHeader
{
public:
	System::Byte version;
	System::Byte layer;
	bool protection;
	int bitrate;
	int samplerate;
	System::Byte channelmode;
	System::Byte extension;
	bool copyright;
	bool original;
	System::Byte emphasis;
	bool padding;
	System::Word framelength;
	bool valid;
};


struct DECLSPEC_DRECORD TXingHeader
{
public:
	int Frames;
	int Size;
	bool vbr;
	bool valid;
	bool corrupted;
};


typedef TXingHeader TVBRIHeader;

class PASCALIMPLEMENTATION TMpegInfo : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	__int64 FFilesize;
	int Fversion;
	int Flayer;
	bool Fprotection;
	System::Word Fbitrate;
	int Fsamplerate;
	System::Byte Fchannelmode;
	System::Byte Fextension;
	bool Fcopyright;
	bool Foriginal;
	System::Byte Femphasis;
	int Fframes;
	int Fdauer;
	bool Fvbr;
	bool Fvalid;
	__int64 FfirstHeaderPosition;
	TMpegHeader __fastcall GetValidatedHeader(TBuffer aBuffer, int position);
	TXingHeader __fastcall GetXingHeader(const TMpegHeader &aMpegheader, TBuffer aBuffer, int position);
	TXingHeader __fastcall GetVBRIHeader(const TMpegHeader &aMpegheader, TBuffer aBuffer, int position);
	int __fastcall GetFramelength(System::Byte version, System::Byte layer, int bitrate, int Samplerate, bool padding);
	
public:
	__fastcall TMpegInfo();
	TMP3Error __fastcall LoadFromStream(System::Classes::TStream* stream);
	TMP3Error __fastcall LoadFromFile(System::UnicodeString FileName);
	__property __int64 Filesize = {read=FFilesize};
	__property int Version = {read=Fversion, nodefault};
	__property int Layer = {read=Flayer, nodefault};
	__property bool Protection = {read=Fprotection, nodefault};
	__property System::Word Bitrate = {read=Fbitrate, nodefault};
	__property int Samplerate = {read=Fsamplerate, nodefault};
	__property System::Byte Channelmode = {read=Fchannelmode, nodefault};
	__property System::Byte Extension = {read=Fextension, nodefault};
	__property bool Copyright = {read=Fcopyright, nodefault};
	__property bool Original = {read=Foriginal, nodefault};
	__property System::Byte Emphasis = {read=Femphasis, nodefault};
	__property int Frames = {read=Fframes, nodefault};
	__property int Dauer = {read=Fdauer, nodefault};
	__property int Duration = {read=Fdauer, nodefault};
	__property bool Vbr = {read=Fvbr, nodefault};
	__property bool Valid = {read=Fvalid, nodefault};
	__property __int64 FirstHeaderPosition = {read=FfirstHeaderPosition};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TMpegInfo() { }
	
};


typedef System::StaticArray<System::UnicodeString, 4> Mp3fileutils__4;

typedef System::StaticArray<System::UnicodeString, 4> Mp3fileutils__5;

typedef System::StaticArray<System::StaticArray<System::UnicodeString, 4>, 3> Mp3fileutils__6;

typedef System::StaticArray<System::UnicodeString, 4> Mp3fileutils__7;

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::StaticArray<System::StaticArray<System::StaticArray<System::Word, 16>, 3>, 3> MPEG_BIT_RATES;
extern DELPHI_PACKAGE System::StaticArray<System::StaticArray<System::Word, 4>, 3> sample_rates;
extern DELPHI_PACKAGE Mp3fileutils__4 channel_modes;
extern DELPHI_PACKAGE Mp3fileutils__6 extensions;
extern DELPHI_PACKAGE Mp3fileutils__7 emphasis_values;
extern DELPHI_PACKAGE System::AnsiString DefaultRatingDescription;
extern DELPHI_PACKAGE System::Classes::TStringList* LanguageCodes;
extern DELPHI_PACKAGE System::Classes::TStringList* LanguageNames;
extern DELPHI_PACKAGE bool __fastcall IsValidV2TrackString(System::UnicodeString value);
extern DELPHI_PACKAGE bool __fastcall IsValidV1TrackString(System::UnicodeString value);
extern DELPHI_PACKAGE bool __fastcall IsValidYearString(System::UnicodeString value);
extern DELPHI_PACKAGE int __fastcall GetTrackFromV2TrackString(System::UnicodeString value);
}	/* namespace Mp3fileutils */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_MP3FILEUTILS)
using namespace Mp3fileutils;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Mp3fileutilsHPP
