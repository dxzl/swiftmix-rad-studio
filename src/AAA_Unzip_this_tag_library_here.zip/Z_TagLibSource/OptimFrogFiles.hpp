﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'OptimFrogFiles.pas' rev: 34.00 (Windows)

#ifndef OptimfrogfilesHPP
#define OptimfrogfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Apev2Tags.hpp>
#include <Vcl.Dialogs.hpp>

//-- user supplied -----------------------------------------------------------

namespace Optimfrogfiles
{
//-- forward type declarations -----------------------------------------------
struct TOfrHeader;
class DELPHICLASS TOptimFrogFile;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 10> Optimfrogfiles__1;

typedef System::StaticArray<System::UnicodeString, 2> Optimfrogfiles__2;

#pragma pack(push,1)
struct DECLSPEC_DRECORD TOfrHeader
{
public:
	System::StaticArray<char, 4> ID;
	unsigned Size;
	unsigned Length;
	System::Word HiLength;
	System::Byte SampleType;
	System::Byte ChannelMode;
	int SampleRate;
	System::Word EncoderID;
	System::Byte CompressionID;
};
#pragma pack(pop)


class PASCALIMPLEMENTATION TOptimFrogFile : public Apev2tags::TBaseApeFile
{
	typedef Apev2tags::TBaseApeFile inherited;
	
private:
	TOfrHeader fHeader;
	void __fastcall fResetData();
	__int64 __fastcall fGetSamples();
	System::UnicodeString __fastcall fGetVersion();
	System::UnicodeString __fastcall fGetCompression();
	System::Int8 __fastcall fGetBits();
	
protected:
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property System::UnicodeString Version = {read=fGetVersion};
	__property System::UnicodeString Compression = {read=fGetCompression};
	__property System::Int8 Bits = {read=fGetBits, nodefault};
public:
	/* TBaseApeFile.Create */ inline __fastcall TOptimFrogFile() : Apev2tags::TBaseApeFile() { }
	/* TBaseApeFile.Destroy */ inline __fastcall virtual ~TOptimFrogFile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE Optimfrogfiles__1 OFR_COMPRESSION;
extern DELPHI_PACKAGE System::StaticArray<System::Int8, 11> OFR_BITS;
extern DELPHI_PACKAGE Optimfrogfiles__2 OFR_CHANNELMODE;
}	/* namespace Optimfrogfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_OPTIMFROGFILES)
using namespace Optimfrogfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OptimfrogfilesHPP
