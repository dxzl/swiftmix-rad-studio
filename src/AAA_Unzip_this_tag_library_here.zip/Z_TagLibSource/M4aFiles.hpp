﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'M4aFiles.pas' rev: 34.00 (Windows)

#ifndef M4afilesHPP
#define M4afilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.StrUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <AudioFileBasics.hpp>
#include <M4aAtoms.hpp>

//-- user supplied -----------------------------------------------------------

namespace M4afiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TM4AFile;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TM4AFile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	unsigned fBytesBeforeMDTA;
	unsigned fTmpStcoOffset;
	Audiofilebasics::TAudioError __fastcall fPrepareSaving(TM4AFile* ExistingTag, System::Classes::TStream* dest);
	void __fastcall fFixAudioOffsets(System::Classes::TStream* st, int diff);
	Audiofilebasics::TAudioError __fastcall BackupAudioData(System::Classes::TStream* source, System::UnicodeString BackUpFilename);
	Audiofilebasics::TAudioError __fastcall AppendBackup(System::Classes::TStream* Destination, System::UnicodeString BackUpFilename);
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual void __fastcall fSetTitle(System::UnicodeString aValue);
	virtual void __fastcall fSetArtist(System::UnicodeString aValue);
	virtual void __fastcall fSetAlbum(System::UnicodeString aValue);
	virtual void __fastcall fSetYear(System::UnicodeString aValue);
	virtual void __fastcall fSetTrack(System::UnicodeString aValue);
	virtual void __fastcall fSetGenre(System::UnicodeString aValue);
	void __fastcall fSetComment(System::UnicodeString aValue);
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetGenre();
	System::UnicodeString __fastcall fGetComment();
	void __fastcall fSetDisc(System::UnicodeString aValue);
	System::UnicodeString __fastcall fGetDisc();
	void __fastcall __fSetAlbumArtist(System::UnicodeString aValue);
	void __fastcall __fSetGrouping(System::UnicodeString aValue);
	void __fastcall __fSetComposer(System::UnicodeString aValue);
	void __fastcall __fSetDescription(System::UnicodeString aValue);
	void __fastcall __fSetLongDescription(System::UnicodeString aValue);
	void __fastcall __fSetLyrics(System::UnicodeString aValue);
	void __fastcall __fSetCopyright(System::UnicodeString aValue);
	void __fastcall __fSetEncodingTool(System::UnicodeString aValue);
	void __fastcall __fSetEncodedBy(System::UnicodeString aValue);
	void __fastcall __fSetKeywords(System::UnicodeString aValue);
	System::UnicodeString __fastcall __fGetAlbumArtist();
	System::UnicodeString __fastcall __fGetGrouping();
	System::UnicodeString __fastcall __fGetComposer();
	System::UnicodeString __fastcall __fGetDescription();
	System::UnicodeString __fastcall __fGetLongDescription();
	System::UnicodeString __fastcall __fGetLyrics();
	System::UnicodeString __fastcall __fGetCopyright();
	System::UnicodeString __fastcall __fGetEncodingTool();
	System::UnicodeString __fastcall __fGetEncodedBy();
	System::UnicodeString __fastcall __fGetKeywords();
	
public:
	M4aatoms::TBaseAtom* FTYP;
	M4aatoms::TMoovAtom* MOOV;
	M4aatoms::TBaseAtom* PADDING;
	bool UsePadding;
	__property System::UnicodeString Comment = {read=fGetComment, write=fSetComment};
	__property System::UnicodeString Disc = {read=fGetDisc, write=fSetDisc};
	__property System::UnicodeString AlbumArtist = {read=__fGetAlbumArtist, write=__fSetAlbumArtist};
	__property System::UnicodeString Grouping = {read=__fGetGrouping, write=__fSetGrouping};
	__property System::UnicodeString Composer = {read=__fGetComposer, write=__fSetComposer};
	__property System::UnicodeString Description = {read=__fGetDescription, write=__fSetDescription};
	__property System::UnicodeString LongDescription = {read=__fGetLongDescription, write=__fSetLongDescription};
	__property System::UnicodeString Lyrics = {read=__fGetLyrics, write=__fSetLyrics};
	__property System::UnicodeString Copyright = {read=__fGetCopyright, write=__fSetCopyright};
	__property System::UnicodeString EncodingTool = {read=__fGetEncodingTool, write=__fSetEncodingTool};
	__property System::UnicodeString EncodedBy = {read=__fGetEncodedBy, write=__fSetEncodedBy};
	__property System::UnicodeString Keywords = {read=__fGetKeywords, write=__fSetKeywords};
	__fastcall TM4AFile();
	__fastcall virtual ~TM4AFile();
	void __fastcall Clear();
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
	bool __fastcall GetPictureStream(System::Classes::TStream* Dest, M4aatoms::TM4APicTypes &typ);
	void __fastcall SetPicture(System::Classes::TStream* Source, M4aatoms::TM4APicTypes typ);
	System::UnicodeString __fastcall GetTextDataByDescription(System::UnicodeString aDescription);
	System::UnicodeString __fastcall GetSpecialData(System::AnsiString mean, System::AnsiString name);
	void __fastcall SetSpecialData(System::AnsiString mean, System::AnsiString name, System::UnicodeString aValue);
	void __fastcall GetAllTextAtomDescriptions(System::Classes::TStrings* dest);
	void __fastcall GetAllTextAtoms(System::Contnrs::TObjectList* dest);
	void __fastcall GetAllAtoms(System::Contnrs::TObjectList* dest);
	void __fastcall RemoveMetaAtom(M4aatoms::TMetaAtom* aAtom);
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::AnsiString DEFAULT_MEAN;
}	/* namespace M4afiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_M4AFILES)
using namespace M4afiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// M4afilesHPP
