﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ID3v2Frames.pas' rev: 34.00 (Windows)

#ifndef Id3v2framesHPP
#define Id3v2framesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Winapi.Windows.hpp>
#include <Vcl.Dialogs.hpp>
#include <U_CharCode.hpp>

//-- user supplied -----------------------------------------------------------

namespace Id3v2frames
{
//-- forward type declarations -----------------------------------------------
struct TID3v2FrameDescriptionData;
class DELPHICLASS TID3v2Frame;
//-- type declarations -------------------------------------------------------
typedef System::Classes::TFileStream TMPFUFileStream;

enum DECLSPEC_DENUM TID3v2FrameTypes : unsigned char { FT_INVALID, FT_UNKNOWN, FT_TextFrame, FT_CommentFrame, FT_LyricFrame, FT_UserDefinedURLFrame, FT_PictureFrame, FT_PopularimeterFrame, FT_URLFrame, FT_UserTextFrame };

enum DECLSPEC_DENUM TID3v2FrameVersions : unsigned char { FV_2 = 2, FV_3, FV_4 };

enum DECLSPEC_DENUM TFrameFlags : unsigned char { FF_TagAlter, FF_FileAlter, FF_ReadOnly, FF_UnknownStatus, FF_Compression, FF_Encryption, FF_GroupID, FF_Unsync, FF_DataLength, FF_UnknownFormat };

enum DECLSPEC_DENUM TFrameIDs : unsigned char { IDv2_UNKNOWN, IDv2_MP3FileUtilsExperimental, IDv2_ARTIST, IDv2_TITEL, IDv2_ALBUM, IDv2_YEAR, IDv2_GENRE, IDv2_TRACK, IDv2_COMPOSER, IDv2_ORIGINALARTIST, IDv2_COPYRIGHT, IDv2_ENCODEDBY, IDv2_LANGUAGES, IDv2_SOFTWARESETTINGS, IDv2_MEDIATYPE, IDv2_LENGTH, IDv2_PUBLISHER, IDv2_ORIGINALFILENAME, IDv2_ORIGINALLYRICIST, IDv2_ORIGINALRELEASEYEAR, IDv2_ORIGINALALBUMTITEL, IDv2_BPM, IDv2_PLAYLISTDELAY, IDv2_FILETYPE, IDv2_INITIALKEY, IDv2_BANDACCOMPANIMENT, IDv2_CONDUCTORREFINEMENT, IDv2_INTERPRETEDBY, IDv2_PARTOFASET, IDv2_ISRC, IDv2_CONTENTGROUPDESCRIPTION, IDv2_SUBTITLEREFINEMENT, IDv2_LYRICIST, IDv2_FILEOWNER, IDv2_INTERNETRADIONAME, IDv2_INTERNETRADIOOWNER, IDv2_ENCODINGTIME, IDv2_RECORDINGTIME, IDv2_RELEASETIME, 
	IDv2_TAGGINGTIME, IDv2_MUSICIANCREDITLIST, IDv2_MOOD, IDv2_PRODUCEDNOTICE, IDv2_ALBUMSORTORDER, IDv2_PERFORMERSORTORDER, IDv2_TITLESORTORDER, IDv2_SETSUBTITLE, IDv2_USERDEFINEDTEXT, IDv2_AUDIOFILEURL, IDv2_ARTISTURL, IDv2_AUDIOSOURCEURL, IDv2_COMMERCIALURL, IDv2_COPYRIGHTURL, IDv2_PUBLISHERSURL, IDv2_RADIOSTATIONURL, IDv2_PAYMENTURL, IDv2_PICTURE, IDv2_LYRICS, IDv2_COMMENT, IDv2_RATING, IDv2_USERDEFINEDURL, IDv2_RECOMMENDEDBUFFERSIZE, IDv2_PLAYCOUNTER, IDv2_AUDIOENCRYPTION, IDv2_EVENTTIMINGCODES, IDv2_EQUALIZATION, IDv2_GENERALOBJECT, IDv2_LINKEDINFORMATION, IDv2_MUSICCDID, IDv2_MPEGLOOKUPTABLE, IDv2_REVERB, IDv2_VOLUMEADJUSTMENT, IDv2_SYNCHRONIZEDLYRICS, IDv2_SYNCEDTEMPOCODES, IDv2_UNIQUEFILEID, IDv2_COMMERCIALFRAME, IDv2_ENCRYPTIONMETHODREGISTRATION, 
	IDv2_GROUPIDREGISTRATION, IDv2_OWNERSHIP, IDv2_PRIVATE, IDv2_POSITIONSYNCHRONISATION, IDv2_TERMSOFUSE, IDv2_SEEKPOINTINDEX, IDv2_SEEKFRAME, IDv2_SIGNATURE, IDv2_INVOLVEDPEOPLE, IDv2_ENCRYPTEDMETAFRAME, IDv2_RECORDINGDATES, IDv2_DATE, IDv2_TIME, IDv2_SIZE };

enum DECLSPEC_DENUM TTextEncoding : unsigned char { TE_Ansi, TE_UTF16, TE_UTF16BE, UTF8 };

struct DECLSPEC_DRECORD TID3v2FrameDescriptionData
{
	
private:
	typedef System::StaticArray<System::AnsiString, 3> _TID3v2FrameDescriptionData__1;
	
	
public:
	_TID3v2FrameDescriptionData__1 IDs;
	System::UnicodeString Description;
};


typedef System::DynamicArray<System::Byte> TBuffer;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TID3v2Frame : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TID3v2FrameVersions fVersion;
	System::AnsiString fIDString;
	TFrameIDs fID;
	TBuffer fHeader;
	TBuffer fData;
	System::Byte fGroupID;
	int fDataLength;
	bool fAlwaysWriteUnicode;
	bool fAutoCorrectCodepage;
	U_charcode::TCodePage fCharCode;
	bool fParsable;
	bool __fastcall ValidFrameID();
	TID3v2FrameTypes __fastcall GetFrameType();
	System::UnicodeString __fastcall GetFrameTypeDescription();
	TFrameIDs __fastcall GetFrameTypeID();
	bool __fastcall GetFlagTagAlterPreservation();
	bool __fastcall GetFlagFileAlterPreservation();
	bool __fastcall GetFlagReadOnly();
	bool __fastcall GetFlagCompression();
	bool __fastcall GetFlagEncryption();
	bool __fastcall GetFlagGroupingIdentity();
	void __fastcall SetFlagGroupingIdentity(bool Value);
	bool __fastcall GetFlagUnsynchronisation();
	bool __fastcall GetFlagDataLengthIndicator();
	bool __fastcall GetUnknownStatusFlags();
	bool __fastcall GetUnknownEncodingFlags();
	void __fastcall SetFlag(TFrameFlags aFlag);
	void __fastcall UnSetFlag(TFrameFlags aFlag);
	void __fastcall UnSetFlagSomeFlagsAfterDataSet();
	int __fastcall GetDataSize();
	void __fastcall SyncStream(System::Classes::TStream* Source, System::Classes::TStream* Target, int aSize);
	void __fastcall UpdateHeader(int aSize = 0xffffffff);
	bool __fastcall IsUnicodeNeeded(System::UnicodeString aString);
	System::UnicodeString __fastcall GetConvertedUnicodeText(int Start, int Ende, TTextEncoding TextEncoding);
	int __fastcall WideStringToData(System::UnicodeString Value, int start, bool UnicodeIsNeeded);
	int __fastcall AnsiStringToData(System::AnsiString Value, int start);
	
public:
	__property TID3v2FrameTypes FrameType = {read=GetFrameType, nodefault};
	__property System::UnicodeString FrameTypeDescription = {read=GetFrameTypeDescription};
	__property System::AnsiString FrameIDString = {read=fIDString};
	__property TFrameIDs FrameID = {read=GetFrameTypeID, nodefault};
	__property bool FlagTagAlterPreservation = {read=GetFlagTagAlterPreservation, nodefault};
	__property bool FlagFileAlterPreservation = {read=GetFlagFileAlterPreservation, nodefault};
	__property bool FlagReadOnly = {read=GetFlagReadOnly, nodefault};
	__property bool FlagCompression = {read=GetFlagCompression, nodefault};
	__property bool FlagEncryption = {read=GetFlagEncryption, nodefault};
	__property bool FlagGroupingIndentity = {read=GetFlagGroupingIdentity, write=SetFlagGroupingIdentity, nodefault};
	__property bool FlagUnsynchronisation = {read=GetFlagUnsynchronisation, nodefault};
	__property bool FlagDataLengthIndicator = {read=GetFlagDataLengthIndicator, nodefault};
	__property bool FlagUnknownStatus = {read=GetUnknownStatusFlags, nodefault};
	__property bool FlagUnknownEncoding = {read=GetUnknownEncodingFlags, nodefault};
	__property System::Byte GroupID = {read=fGroupID, write=fGroupID, nodefault};
	__property int DataSize = {read=GetDataSize, nodefault};
	__property bool AlwaysWriteUnicode = {read=fAlwaysWriteUnicode, write=fAlwaysWriteUnicode, nodefault};
	__property U_charcode::TCodePage CharCode = {read=fCharCode, write=fCharCode};
	__property bool AutoCorrectCodepage = {read=fAutoCorrectCodepage, write=fAutoCorrectCodepage, nodefault};
	__fastcall TID3v2Frame(System::AnsiString aID, TID3v2FrameVersions aVersion);
	void __fastcall ReadFromStream(System::Classes::TStream* aStream);
	void __fastcall WriteToStream(System::Classes::TStream* aStream);
	void __fastcall WriteUnsyncedToStream(System::Classes::TStream* aStream);
	System::UnicodeString __fastcall GetText();
	void __fastcall SetText(System::UnicodeString Value);
	System::UnicodeString __fastcall GetUserText(/* out */ System::UnicodeString &Description);
	void __fastcall SetUserText(System::UnicodeString Description, System::UnicodeString Value);
	System::UnicodeString __fastcall GetCommentsLyrics(/* out */ System::AnsiString &Language, /* out */ System::UnicodeString &Description);
	void __fastcall SetCommentsLyrics(System::AnsiString Language, System::UnicodeString Description, System::UnicodeString Value);
	System::AnsiString __fastcall GetUserdefinedURL(/* out */ System::UnicodeString &Description);
	void __fastcall SetUserdefinedURL(System::UnicodeString Description, System::AnsiString URL);
	System::AnsiString __fastcall GetURL();
	void __fastcall SetURL(System::AnsiString Value);
	bool __fastcall GetPicture(/* out */ System::AnsiString &Mime, /* out */ System::Byte &PicType, /* out */ System::UnicodeString &Description, System::Classes::TStream* PictureData);
	void __fastcall SetPicture(System::AnsiString Mime, System::Byte PicType, System::UnicodeString Description, System::Classes::TStream* PictureData);
	System::Byte __fastcall GetRating(/* out */ System::AnsiString &UserEMail);
	void __fastcall SetRating(System::AnsiString UserEMail, System::Byte Value);
	unsigned __fastcall GetPersonalPlayCounter(/* out */ System::AnsiString &UserEMail);
	void __fastcall SetPersonalPlayCounter(System::AnsiString UserEMail, unsigned Value);
	bool __fastcall GetPrivateFrame(/* out */ System::AnsiString &OwnerID, System::Classes::TStream* Data);
	void __fastcall SetPrivateFrame(System::AnsiString aOwnerID, System::Classes::TStream* Data);
	void __fastcall GetData(System::Classes::TStream* Data);
	void __fastcall SetData(System::Classes::TStream* Data);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TID3v2Frame() { }
	
};

#pragma pack(pop)

typedef System::StaticArray<TID3v2FrameDescriptionData, 91> Id3v2frames__2;

typedef System::StaticArray<System::UnicodeString, 21> Id3v2frames__3;

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE System::StaticArray<System::StaticArray<System::Byte, 10>, 3> TFrameFlagValues;
extern DELPHI_PACKAGE Id3v2frames__2 ID3v2KnownFrames;
extern DELPHI_PACKAGE Id3v2frames__3 Picture_Types;
extern DELPHI_PACKAGE bool __fastcall UnSyncStream(System::Classes::TStream* Source, System::Classes::TStream* Target);
extern DELPHI_PACKAGE void __fastcall SetStreamEnd(System::Classes::TStream* aStream);
}	/* namespace Id3v2frames */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_ID3V2FRAMES)
using namespace Id3v2frames;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Id3v2framesHPP
