﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'MusePackFiles.pas' rev: 34.00 (Windows)

#ifndef MusepackfilesHPP
#define MusepackfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Apev2Tags.hpp>
#include <Vcl.Dialogs.hpp>

//-- user supplied -----------------------------------------------------------

namespace Musepackfiles
{
//-- forward type declarations -----------------------------------------------
struct HeaderRecord;
class DELPHICLASS TMusePackFile;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 3> Musepackfiles__1;

struct DECLSPEC_DRECORD HeaderRecord
{
public:
	System::StaticArray<System::Byte, 32> ByteArray;
	System::StaticArray<int, 8> IntegerArray;
};


class PASCALIMPLEMENTATION TMusePackFile : public Apev2tags::TBaseApeFile
{
	typedef Apev2tags::TBaseApeFile inherited;
	
public:
	HeaderRecord fHeader;
	int fDataIndex;
	bool fValid;
	System::Byte fChannelModeID;
	int fFrameCount;
	__int64 fSampleCount;
	System::Byte fStreamVersion;
	void __fastcall fResetData();
	System::UnicodeString __fastcall fGetChannelMode();
	bool __fastcall fIsCorrupted();
	double __fastcall fGetRatio();
	System::UnicodeString __fastcall fGetVersionString();
	System::Byte __fastcall fGetStreamVersion();
	System::Byte __fastcall fGetChannelModeID();
	int __fastcall fGetFrameCount();
	__int64 __fastcall fGetSampleCount();
	
protected:
	virtual int __fastcall fGetChannels();
	virtual int __fastcall fGetSamplerate();
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property System::UnicodeString ChannelMode = {read=fGetChannelMode};
	__property System::Byte ChannelModeID = {read=fGetChannelModeID, nodefault};
	__property System::UnicodeString VersionString = {read=fGetVersionString};
public:
	/* TBaseApeFile.Create */ inline __fastcall TMusePackFile() : Apev2tags::TBaseApeFile() { }
	/* TBaseApeFile.Destroy */ inline __fastcall virtual ~TMusePackFile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const System::Int8 MPP_CM_STEREO = System::Int8(0x1);
static const System::Int8 MPP_CM_JOINT_STEREO = System::Int8(0x2);
extern DELPHI_PACKAGE Musepackfiles__1 MPP_MODE;
}	/* namespace Musepackfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_MUSEPACKFILES)
using namespace Musepackfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MusepackfilesHPP
