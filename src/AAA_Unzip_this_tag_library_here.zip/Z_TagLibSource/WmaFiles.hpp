﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WmaFiles.pas' rev: 34.00 (Windows)

#ifndef WmafilesHPP
#define WmafilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>
#include <AudioFileBasics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Wmafiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWMAfile;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 3> Wmafiles__1;

class PASCALIMPLEMENTATION TWMAfile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	System::Byte fChannelModeID;
	System::UnicodeString fTitle;
	System::UnicodeString fArtist;
	System::UnicodeString fAlbum;
	System::UnicodeString fTrack;
	System::UnicodeString fYear;
	System::UnicodeString fGenre;
	System::UnicodeString fComment;
	void __fastcall fResetData();
	System::UnicodeString __fastcall fGetChannelMode();
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual void __fastcall fSetTitle(System::UnicodeString aValue);
	virtual void __fastcall fSetArtist(System::UnicodeString aValue);
	virtual void __fastcall fSetAlbum(System::UnicodeString aValue);
	virtual void __fastcall fSetYear(System::UnicodeString aValue);
	virtual void __fastcall fSetTrack(System::UnicodeString aValue);
	virtual void __fastcall fSetGenre(System::UnicodeString aValue);
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetGenre();
	
public:
	__fastcall TWMAfile();
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
	__property System::Byte ChannelModeID = {read=fChannelModeID, nodefault};
	__property System::UnicodeString ChannelMode = {read=fGetChannelMode};
	__property System::UnicodeString Comment = {read=fComment};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TWMAfile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const System::Int8 WMA_CM_UNKNOWN = System::Int8(0x0);
static const System::Int8 WMA_CM_MONO = System::Int8(0x1);
static const System::Int8 WMA_CM_STEREO = System::Int8(0x2);
extern DELPHI_PACKAGE Wmafiles__1 WMA_MODE;
}	/* namespace Wmafiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WMAFILES)
using namespace Wmafiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// WmafilesHPP
