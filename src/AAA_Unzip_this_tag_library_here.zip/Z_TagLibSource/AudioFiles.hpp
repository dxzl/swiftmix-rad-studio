﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AudioFiles.pas' rev: 34.00 (Windows)

#ifndef AudiofilesHPP
#define AudiofilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Classes.hpp>
#include <System.Contnrs.hpp>
#include <AudioFileBasics.hpp>
#include <Apev2Tags.hpp>
#include <ApeTagItem.hpp>
#include <ID3v2Frames.hpp>
#include <Mp3Files.hpp>
#include <FlacFiles.hpp>
#include <OggVorbisFiles.hpp>
#include <M4aFiles.hpp>
#include <MonkeyFiles.hpp>
#include <WavPackFiles.hpp>
#include <MusePackFiles.hpp>
#include <OptimFrogFiles.hpp>
#include <TrueAudioFiles.hpp>
#include <WmaFiles.hpp>
#include <WavFiles.hpp>

//-- user supplied -----------------------------------------------------------

namespace Audiofiles
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TGeneralAudioFile;
//-- type declarations -------------------------------------------------------
enum DECLSPEC_DENUM TAudioFileType : unsigned char { at_Invalid, at_Mp3, at_Ogg, at_Flac, at_M4A, at_Monkey, at_WavPack, at_MusePack, at_OptimFrog, at_TrueAudio, at_Wma, at_Wav };

typedef System::StaticArray<System::UnicodeString, 12> Audiofiles__1;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TGeneralAudioFile : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Audiofilebasics::TBaseAudioFile* fBaseAudioFile;
	TAudioFileType fFileType;
	System::UnicodeString fFilename;
	Audiofilebasics::TAudioError fLastError;
	System::UnicodeString __fastcall fGetFileTypeName();
	__int64 __fastcall fGetFileSize();
	int __fastcall fGetDuration();
	int __fastcall fGetBitrate();
	int __fastcall fGetSamplerate();
	int __fastcall fGetChannels();
	bool __fastcall fGetValid();
	System::UnicodeString __fastcall fGetTitle();
	System::UnicodeString __fastcall fGetArtist();
	System::UnicodeString __fastcall fGetAlbum();
	System::UnicodeString __fastcall fGetYear();
	System::UnicodeString __fastcall fGetTrack();
	System::UnicodeString __fastcall fGetGenre();
	void __fastcall fSetTitle(System::UnicodeString aValue);
	void __fastcall fSetArtist(System::UnicodeString aValue);
	void __fastcall fSetAlbum(System::UnicodeString aValue);
	void __fastcall fSetYear(System::UnicodeString aValue);
	void __fastcall fSetTrack(System::UnicodeString aValue);
	void __fastcall fSetGenre(System::UnicodeString aValue);
	Mp3files::TMP3File* __fastcall fGetMP3File();
	Oggvorbisfiles::TOggVorbisFile* __fastcall fGetOggFile();
	Flacfiles::TFlacFile* __fastcall fGetFlacFile();
	M4afiles::TM4AFile* __fastcall fGetM4AFile();
	Apev2tags::TBaseApeFile* __fastcall fGetBaseApeFile();
	Monkeyfiles::TMonkeyFile* __fastcall fGetMonkeyFile();
	Wavpackfiles::TWavPackFile* __fastcall fGetWavPackFile();
	Musepackfiles::TMusePackFile* __fastcall fMusePackGetFile();
	Optimfrogfiles::TOptimFrogFile* __fastcall fGetOptimFrogFile();
	Trueaudiofiles::TTrueAudioFile* __fastcall fGetTrueAudioFile();
	Wmafiles::TWMAfile* __fastcall fGetWmaFile();
	Wavfiles::Twavfile* __fastcall fGetWavFile();
	
public:
	__property bool Valid = {read=fGetValid, nodefault};
	__property __int64 FileSize = {read=fGetFileSize};
	__property int Duration = {read=fGetDuration, nodefault};
	__property int Bitrate = {read=fGetBitrate, nodefault};
	__property int Samplerate = {read=fGetSamplerate, nodefault};
	__property int Channels = {read=fGetChannels, nodefault};
	__property System::UnicodeString Title = {read=fGetTitle, write=fSetTitle};
	__property System::UnicodeString Artist = {read=fGetArtist, write=fSetArtist};
	__property System::UnicodeString Album = {read=fGetAlbum, write=fSetAlbum};
	__property System::UnicodeString Year = {read=fGetYear, write=fSetYear};
	__property System::UnicodeString Track = {read=fGetTrack, write=fSetTrack};
	__property System::UnicodeString Genre = {read=fGetGenre, write=fSetGenre};
	__property Mp3files::TMP3File* MP3File = {read=fGetMP3File};
	__property Oggvorbisfiles::TOggVorbisFile* OggFile = {read=fGetOggFile};
	__property Flacfiles::TFlacFile* FlacFile = {read=fGetFlacFile};
	__property M4afiles::TM4AFile* M4aFile = {read=fGetM4AFile};
	__property Apev2tags::TBaseApeFile* BaseApeFile = {read=fGetBaseApeFile};
	__property Monkeyfiles::TMonkeyFile* MonkeyFile = {read=fGetMonkeyFile};
	__property Wavpackfiles::TWavPackFile* WavPackFile = {read=fGetWavPackFile};
	__property Musepackfiles::TMusePackFile* MusePackFile = {read=fMusePackGetFile};
	__property Optimfrogfiles::TOptimFrogFile* OptimFrogFile = {read=fGetOptimFrogFile};
	__property Trueaudiofiles::TTrueAudioFile* TrueAudioFile = {read=fGetTrueAudioFile};
	__property Wmafiles::TWMAfile* WmaFile = {read=fGetWmaFile};
	__property Wavfiles::Twavfile* WavFile = {read=fGetWavFile};
	__property TAudioFileType FileType = {read=fFileType, nodefault};
	__property System::UnicodeString Filename = {read=fFilename};
	__property System::UnicodeString FileTypeName = {read=fGetFileTypeName};
	__property Audiofilebasics::TAudioError LastError = {read=fLastError, nodefault};
	__fastcall TGeneralAudioFile(System::UnicodeString aFilename);
	__fastcall virtual ~TGeneralAudioFile();
	Audiofilebasics::TAudioError __fastcall UpdateFile();
	Audiofilebasics::TAudioError __fastcall RemoveFromFile();
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE Audiofiles__1 TAudioFileNames;
}	/* namespace Audiofiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_AUDIOFILES)
using namespace Audiofiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AudiofilesHPP
