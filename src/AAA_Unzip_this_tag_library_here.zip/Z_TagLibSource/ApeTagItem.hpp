﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApeTagItem.pas' rev: 34.00 (Windows)

#ifndef ApetagitemHPP
#define ApetagitemHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <AudioFileBasics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Apetagitem
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TApeTagItem;
//-- type declarations -------------------------------------------------------
enum DECLSPEC_DENUM TApePictureTypes : unsigned char { apt_Arbitrary, apt_Other, apt_Icon, apt_OtherIcon, apt_Front, apt_Back, apt_Leaflet, apt_Media, apt_Lead, apt_Artist, apt_Conductor, apt_Band, apt_Composer, apt_Lyricist, apt_Studio, apt_Recording, apt_Performance, apt_MovieScene, apt_ColoredFish, apt_Illustration, apt_BandLogo, apt_PublisherLogo };

typedef System::StaticArray<System::AnsiString, 22> Apetagitem__1;

typedef System::DynamicArray<System::Byte> TBuffer;

enum DECLSPEC_DENUM TApeTagItemContentType : unsigned char { ctText, ctBinary, ctExternal, ctreserved };

#pragma pack(push,4)
class PASCALIMPLEMENTATION TApeTagItem : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int fValueSize;
	unsigned fFlags;
	System::AnsiString fKey;
	System::UTF8String fValue;
	TBuffer fData;
	bool __fastcall fCheckKey(System::AnsiString aKey);
	int __fastcall fGetCompleteSize();
	void __fastcall fSetValue(System::UnicodeString aValue);
	System::UnicodeString __fastcall fGetValue();
	void __fastcall fSetContentType(TApeTagItemContentType aValue);
	TApeTagItemContentType __fastcall fGetContentType();
	void __fastcall fSetReadOnly(bool aValue);
	bool __fastcall fGetReadOnly();
	
public:
	__property int ValueSize = {read=fValueSize, nodefault};
	__property int CompleteSize = {read=fGetCompleteSize, nodefault};
	__property unsigned Flags = {read=fFlags, nodefault};
	__property System::AnsiString Key = {read=fKey};
	__property System::UnicodeString Value = {read=fGetValue, write=fSetValue};
	__property TApeTagItemContentType ContentType = {read=fGetContentType, write=fSetContentType, nodefault};
	__property bool ReadOnlyFlag = {read=fGetReadOnly, write=fSetReadOnly, nodefault};
	__fastcall TApeTagItem(System::AnsiString aKey);
	bool __fastcall GetBinaryData(System::Classes::TStream* dest);
	void __fastcall SetBinaryData(System::Classes::TStream* source);
	bool __fastcall GetPicture(System::Classes::TStream* dest, System::UnicodeString &description);
	void __fastcall SetPicture(System::Classes::TStream* source, System::UnicodeString description);
	bool __fastcall ReadFromStream(System::Classes::TStream* aStream);
	bool __fastcall WriteToStream(System::Classes::TStream* aStream);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TApeTagItem() { }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE Apetagitem__1 TPictureTypeStrings;
}	/* namespace Apetagitem */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_APETAGITEM)
using namespace Apetagitem;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApetagitemHPP
