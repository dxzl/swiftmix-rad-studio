﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'TrueAudioFiles.pas' rev: 34.00 (Windows)

#ifndef TrueaudiofilesHPP
#define TrueaudiofilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Apev2Tags.hpp>
#include <Vcl.Dialogs.hpp>

//-- user supplied -----------------------------------------------------------

namespace Trueaudiofiles
{
//-- forward type declarations -----------------------------------------------
struct tta_header;
class DELPHICLASS TTrueAudioFile;
//-- type declarations -------------------------------------------------------
#pragma pack(push,1)
struct DECLSPEC_DRECORD tta_header
{
public:
	System::StaticArray<char, 4> ID;
	System::Word AudioFormat;
	System::Word NumChannels;
	System::Word BitsPerSample;
	unsigned SampleRate;
	unsigned DataLength;
	unsigned CRC32;
};
#pragma pack(pop)


class PASCALIMPLEMENTATION TTrueAudioFile : public Apev2tags::TBaseApeFile
{
	typedef Apev2tags::TBaseApeFile inherited;
	
private:
	tta_header fHeader;
	unsigned fAudioFormat;
	unsigned fBits;
	unsigned fSamples;
	unsigned fCRC32;
	void __fastcall fResetData();
	
protected:
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property unsigned Bits = {read=fBits, nodefault};
	__property unsigned AudioFormat = {read=fAudioFormat, nodefault};
public:
	/* TBaseApeFile.Create */ inline __fastcall TTrueAudioFile() : Apev2tags::TBaseApeFile() { }
	/* TBaseApeFile.Destroy */ inline __fastcall virtual ~TTrueAudioFile() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Trueaudiofiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_TRUEAUDIOFILES)
using namespace Trueaudiofiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// TrueaudiofilesHPP
