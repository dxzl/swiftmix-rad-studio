﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'M4aAtoms.pas' rev: 34.00 (Windows)

#ifndef M4aatomsHPP
#define M4aatomsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.StrUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <AudioFileBasics.hpp>
#include <System.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace M4aatoms
{
//-- forward type declarations -----------------------------------------------
struct TMetaAtomDescription;
class DELPHICLASS TBaseAtom;
class DELPHICLASS TFreeAtom;
class DELPHICLASS TTrakAtom;
class DELPHICLASS TMetaAtom;
class DELPHICLASS TUdtaAtom;
class DELPHICLASS TMoovAtom;
//-- type declarations -------------------------------------------------------
typedef System::DynamicArray<System::Byte> TBuffer;

typedef System::StaticArray<char, 4> TAtomName;

enum DECLSPEC_DENUM TM4APicTypes : unsigned char { M4A_JPG = 13, M4A_PNG, M4A_Invalid };

struct DECLSPEC_DRECORD TMetaAtomDescription
{
public:
	TAtomName AtomName;
	System::UnicodeString Description;
};


typedef System::StaticArray<TMetaAtomDescription, 27> M4aatoms__1;

#pragma pack(push,4)
class PASCALIMPLEMENTATION TBaseAtom : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TAtomName fName;
	System::Classes::TMemoryStream* fData;
	unsigned __fastcall fGetSize();
	
public:
	__property TAtomName Name = {read=fName};
	__property unsigned Size = {read=fGetSize, nodefault};
	__fastcall virtual TBaseAtom(TAtomName aName);
	__fastcall virtual ~TBaseAtom();
	virtual void __fastcall Clear();
	int __fastcall ReadFromStream(System::Classes::TStream* aStream, unsigned aSize);
	__int64 __fastcall SaveToStream(System::Classes::TStream* aStream);
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TFreeAtom : public TBaseAtom
{
	typedef TBaseAtom inherited;
	
public:
	__fastcall TFreeAtom(TAtomName aName, unsigned aSize);
public:
	/* TBaseAtom.Create */ inline __fastcall virtual TFreeAtom(TAtomName aName) : TBaseAtom(aName) { }
	/* TBaseAtom.Destroy */ inline __fastcall virtual ~TFreeAtom() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TTrakAtom : public TBaseAtom
{
	typedef TBaseAtom inherited;
	
private:
	int fBitrate;
	int fSamplerate;
	int fChannels;
	int fDuration;
	bool fValid;
	unsigned fOffsetPosition;
	unsigned fOffsetCount;
	unsigned fAudioOffset;
	Audiofilebasics::TAudioError __fastcall Parse1_MDIA(unsigned aSize);
	Audiofilebasics::TAudioError __fastcall Parse2_MDHD(unsigned aSize);
	Audiofilebasics::TAudioError __fastcall Parse3_MINF(unsigned aSize);
	Audiofilebasics::TAudioError __fastcall Parse4_STBL(unsigned aSize);
	Audiofilebasics::TAudioError __fastcall Parse5_STSD(unsigned aSize);
	Audiofilebasics::TAudioError __fastcall Parse6_STCO(unsigned aSize);
	
public:
	virtual void __fastcall Clear();
	Audiofilebasics::TAudioError __fastcall ParseData();
public:
	/* TBaseAtom.Create */ inline __fastcall virtual TTrakAtom(TAtomName aName) : TBaseAtom(aName) { }
	/* TBaseAtom.Destroy */ inline __fastcall virtual ~TTrakAtom() { }
	
};

#pragma pack(pop)

enum DECLSPEC_DENUM TTrackDisc : unsigned char { meta_Track, meta_Disc };

#pragma pack(push,4)
class PASCALIMPLEMENTATION TMetaAtom : public TBaseAtom
{
	typedef TBaseAtom inherited;
	
private:
	void __fastcall prepareDiskTrackAtom(TTrackDisc l, System::UnicodeString aValue);
	void __fastcall WriteHeader(unsigned aSize);
	
public:
	System::UnicodeString __fastcall GetTextData();
	System::UnicodeString __fastcall GetTrackNumber();
	System::UnicodeString __fastcall GetGenre();
	System::UnicodeString __fastcall GetDiscNumber();
	void __fastcall SetTextData(System::UnicodeString aValue);
	void __fastcall SetTrackNumber(System::UnicodeString aValue);
	void __fastcall SetStandardGenre(int idx);
	void __fastcall SetDiscNumber(System::UnicodeString aValue);
	bool __fastcall GetPictureStream(System::Classes::TStream* Dest, TM4APicTypes &typ);
	void __fastcall SetPicture(System::Classes::TStream* Source, TM4APicTypes typ);
	System::UnicodeString __fastcall GetSpecialData(/* out */ System::AnsiString &aMean, /* out */ System::AnsiString &aName);
	void __fastcall SetSpecialData(System::AnsiString aMean, System::AnsiString aName, System::UnicodeString aValue);
	bool __fastcall ContainsTextData();
	System::UnicodeString __fastcall GetListDescription();
public:
	/* TBaseAtom.Create */ inline __fastcall virtual TMetaAtom(TAtomName aName) : TBaseAtom(aName) { }
	/* TBaseAtom.Destroy */ inline __fastcall virtual ~TMetaAtom() { }
	
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TUdtaAtom : public TBaseAtom
{
	typedef TBaseAtom inherited;
	
private:
	System::Contnrs::TObjectList* fMetaAtoms;
	TMetaAtom* __fastcall fSearchAtom(TAtomName aName);
	TMetaAtom* __fastcall fSearchSpecialAtom(System::AnsiString mean, System::AnsiString name, /* out */ System::UnicodeString &Value);
	void __fastcall fAddDefaultMetaData();
	
public:
	__fastcall virtual TUdtaAtom(TAtomName aName);
	__fastcall virtual ~TUdtaAtom();
	Audiofilebasics::TAudioError __fastcall ParseData();
	System::UnicodeString __fastcall GetTextData(TAtomName aName);
	System::UnicodeString __fastcall GetTrackNumber();
	System::UnicodeString __fastcall GetGenre();
	System::UnicodeString __fastcall GetDiscNumber();
	void __fastcall SetTextData(TAtomName aName, System::UnicodeString aValue);
	void __fastcall SetTrackNumber(System::UnicodeString aValue);
	void __fastcall SetGenre(System::UnicodeString aValue);
	void __fastcall SetDiscNumber(System::UnicodeString aValue);
	bool __fastcall GetPictureStream(System::Classes::TStream* Dest, TM4APicTypes &typ);
	void __fastcall SetPicture(System::Classes::TStream* Source, TM4APicTypes typ);
	System::UnicodeString __fastcall GetSpecialData(System::AnsiString aMean, System::AnsiString aName);
	void __fastcall SetSpecialData(System::AnsiString aMean, System::AnsiString aName, System::UnicodeString aValue);
	void __fastcall GetAllTextAtomDescriptions(System::Classes::TStrings* dest);
	void __fastcall GetAllTextAtoms(System::Contnrs::TObjectList* dest);
	void __fastcall GetAllAtoms(System::Contnrs::TObjectList* dest);
	void __fastcall RemoveAtom(TMetaAtom* aAtom);
	Audiofilebasics::TAudioError __fastcall PrepareDataForSaving();
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TMoovAtom : public TBaseAtom
{
	typedef TBaseAtom inherited;
	
private:
	int fDuration;
	int fSamplerate;
	int fChannels;
	unsigned fAudioDataOffset;
	unsigned fStcoOffset;
	
public:
	System::Contnrs::TObjectList* AtomList;
	TTrakAtom* TrakAtom;
	TUdtaAtom* UdtaAtom;
	__property int Duration = {read=fDuration, nodefault};
	__property int Samplerate = {read=fSamplerate, nodefault};
	__property int Channels = {read=fChannels, nodefault};
	__property unsigned AudioDataOffset = {read=fAudioDataOffset, nodefault};
	__property unsigned StcoOffset = {read=fStcoOffset, nodefault};
	__fastcall virtual TMoovAtom(TAtomName aName);
	__fastcall virtual ~TMoovAtom();
	virtual void __fastcall Clear();
	Audiofilebasics::TAudioError __fastcall ParseData();
	Audiofilebasics::TAudioError __fastcall WriteToStreamWithNewUDTA(System::Classes::TStream* dest, TUdtaAtom* newUDTA);
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE M4aatoms__1 KnownMetaAtoms;
extern DELPHI_PACKAGE Audiofilebasics::TAudioError __fastcall GetNextAtomInfo(System::Classes::TStream* aStream, /* out */ TAtomName &Name, /* out */ unsigned &Size);
extern DELPHI_PACKAGE unsigned __fastcall ChangeEndian32(unsigned X);
extern DELPHI_PACKAGE System::Word __fastcall ChangeEndian16(System::Word X);
}	/* namespace M4aatoms */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_M4AATOMS)
using namespace M4aatoms;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// M4aatomsHPP
