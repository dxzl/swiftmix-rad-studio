﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FlacFiles.pas' rev: 34.00 (Windows)

#ifndef FlacfilesHPP
#define FlacfilesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <AudioFileBasics.hpp>
#include <VorbisComments.hpp>
#include <Id3Basics.hpp>
#include <Winapi.WinSock.hpp>

//-- user supplied -----------------------------------------------------------

namespace Flacfiles
{
//-- forward type declarations -----------------------------------------------
struct TFlacHeader;
class DELPHICLASS TFlacMetaBlock;
class DELPHICLASS TFlacCommentsBlock;
class DELPHICLASS TFlacPictureBlock;
class DELPHICLASS TFlacFile;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::UnicodeString, 21> Flacfiles__1;

typedef System::StaticArray<System::Byte, 4> TMetaDataBlockHeader;

typedef System::DynamicArray<System::Byte> TMetaDataBlockData;

#pragma pack(push,1)
struct DECLSPEC_DRECORD TFlacHeader
{
public:
	System::StaticArray<char, 4> StreamMarker;
	TMetaDataBlockHeader MetaDataBlockHeader;
	System::StaticArray<System::Byte, 18> Info;
	System::StaticArray<System::Byte, 16> MD5Sum;
};
#pragma pack(pop)


class PASCALIMPLEMENTATION TFlacMetaBlock : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TMetaDataBlockHeader fHeader;
	TMetaDataBlockData fData;
	__int64 fPositionInStream;
	unsigned __fastcall fGetDataSize();
	void __fastcall fSetDataSize(unsigned aSize);
	bool __fastcall fGetLastBlock();
	void __fastcall fSetLastBlock(bool Value);
	void __fastcall fCopyHeader(TMetaDataBlockHeader aSourceHeader);
	System::Byte __fastcall fGetBlockType();
	void __fastcall fSetBlockType(System::Byte value);
	
public:
	__property System::Byte BlockType = {read=fGetBlockType, write=fSetBlockType, nodefault};
	__property bool LastBlockInFile = {read=fGetLastBlock, write=fSetLastBlock, nodefault};
	virtual bool __fastcall ReadFromStream(TMetaDataBlockHeader aSourceHeader, System::Classes::TStream* Source);
	virtual bool __fastcall WriteToStream(System::Classes::TStream* Destination);
public:
	/* TObject.Create */ inline __fastcall TFlacMetaBlock() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TFlacMetaBlock() { }
	
};


class PASCALIMPLEMENTATION TFlacCommentsBlock : public TFlacMetaBlock
{
	typedef TFlacMetaBlock inherited;
	
private:
	Vorbiscomments::TVorbisComments* Comments;
	
public:
	__fastcall TFlacCommentsBlock();
	__fastcall virtual ~TFlacCommentsBlock();
	void __fastcall Clear();
	bool __fastcall IsEmpty();
	virtual bool __fastcall ReadFromStream(TMetaDataBlockHeader aSourceHeader, System::Classes::TStream* Source);
	virtual bool __fastcall WriteToStream(System::Classes::TStream* Destination);
};


class PASCALIMPLEMENTATION TFlacPictureBlock : public TFlacMetaBlock
{
	typedef TFlacMetaBlock inherited;
	
private:
	unsigned fPictureType;
	System::AnsiString fMime;
	System::UTF8String fDescription;
	unsigned fWidth;
	unsigned fHeight;
	unsigned fColorDepth;
	unsigned fNumberOfColors;
	System::Classes::TMemoryStream* fPicData;
	System::UnicodeString __fastcall fGetDescription();
	void __fastcall fSetDescription(System::UnicodeString value);
	unsigned __fastcall fCalculateBlockSize();
	
public:
	__property unsigned PictureType = {read=fPictureType, write=fPictureType, nodefault};
	__property System::AnsiString Mime = {read=fMime, write=fMime};
	__property System::UnicodeString Description = {read=fGetDescription, write=fSetDescription};
	__property unsigned Width = {read=fWidth, write=fWidth, nodefault};
	__property unsigned Height = {read=fHeight, write=fHeight, nodefault};
	__property unsigned ColorDepth = {read=fColorDepth, write=fColorDepth, nodefault};
	__property unsigned NumberOfColors = {read=fNumberOfColors, write=fNumberOfColors, nodefault};
	__fastcall TFlacPictureBlock();
	__fastcall virtual ~TFlacPictureBlock();
	void __fastcall Clear();
	bool __fastcall IsEmpty();
	void __fastcall CopyPicData(System::Classes::TStream* Target);
	virtual bool __fastcall ReadFromStream(TMetaDataBlockHeader aSourceHeader, System::Classes::TStream* Source);
	virtual bool __fastcall WriteToStream(System::Classes::TStream* Destination);
};


class PASCALIMPLEMENTATION TFlacFile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	TFlacHeader fHeader;
	System::Byte fBitsPerSample;
	__int64 fSamples;
	bool fUsePadding;
	int fAudioOffset;
	int fFlacOffset;
	System::Contnrs::TObjectList* fMetaBlocks;
	TFlacCommentsBlock* fFlacCommentsBlock;
	System::UnicodeString __fastcall fGetVersion();
	System::UnicodeString __fastcall fGetPerformer();
	System::UnicodeString __fastcall fGetCopyright();
	System::UnicodeString __fastcall fGetLicense();
	System::UnicodeString __fastcall fGetOrganization();
	System::UnicodeString __fastcall fGetDescription();
	System::UnicodeString __fastcall fGetLocation();
	System::UnicodeString __fastcall fGetContact();
	System::UnicodeString __fastcall fGetISRC();
	void __fastcall fSetVersion(System::UnicodeString value);
	void __fastcall fSetPerformer(System::UnicodeString value);
	void __fastcall fSetCopyright(System::UnicodeString value);
	void __fastcall fSetLicense(System::UnicodeString value);
	void __fastcall fSetOrganization(System::UnicodeString value);
	void __fastcall fSetDescription(System::UnicodeString value);
	void __fastcall fSetLocation(System::UnicodeString value);
	void __fastcall fSetContact(System::UnicodeString value);
	void __fastcall fSetISRC(System::UnicodeString value);
	void __fastcall ClearData();
	void __fastcall ValidateFlacCommentsBlock();
	bool __fastcall fIsValid();
	TFlacPictureBlock* __fastcall fGetArbitraryPictureBlock();
	Audiofilebasics::TAudioError __fastcall PrepareDataToWrite(TFlacFile* tmpFlacFile, System::Classes::TStream* BufferStream, System::UnicodeString aFilename);
	Audiofilebasics::TAudioError __fastcall BackupAudioData(System::Classes::TStream* source, System::UnicodeString BackUpFilename);
	Audiofilebasics::TAudioError __fastcall AppendBackup(System::Classes::TStream* Destination, System::UnicodeString BackUpFilename);
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual void __fastcall fSetTitle(System::UnicodeString Value);
	virtual void __fastcall fSetArtist(System::UnicodeString Value);
	virtual void __fastcall fSetAlbum(System::UnicodeString Value);
	virtual void __fastcall fSetYear(System::UnicodeString Value);
	virtual void __fastcall fSetTrack(System::UnicodeString Value);
	virtual void __fastcall fSetGenre(System::UnicodeString Value);
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetGenre();
	
public:
	__property bool UsePadding = {read=fUsePadding, write=fUsePadding, nodefault};
	__property System::UnicodeString Version = {read=fGetVersion, write=fSetVersion};
	__property System::UnicodeString Performer = {read=fGetPerformer, write=fSetPerformer};
	__property System::UnicodeString Copyright = {read=fGetCopyright, write=fSetCopyright};
	__property System::UnicodeString License = {read=fGetLicense, write=fSetLicense};
	__property System::UnicodeString Organization = {read=fGetOrganization, write=fSetOrganization};
	__property System::UnicodeString Description = {read=fGetDescription, write=fSetDescription};
	__property System::UnicodeString Location = {read=fGetLocation, write=fSetLocation};
	__property System::UnicodeString Contact = {read=fGetContact, write=fSetContact};
	__property System::UnicodeString ISRC = {read=fGetISRC, write=fSetISRC};
	__fastcall TFlacFile();
	__fastcall virtual ~TFlacFile();
	Audiofilebasics::TAudioError __fastcall ReadFromStream(System::Classes::TStream* fs);
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
	bool __fastcall GetPictureStream(System::Classes::TStream* Destination, unsigned &aPicType, System::AnsiString &aMime, System::UnicodeString &aDescription);
	void __fastcall SetPicture(System::Classes::TStream* Source, System::AnsiString aMime, System::UnicodeString aDescription);
	void __fastcall GetAllPictureBlocks(System::Contnrs::TObjectList* aTarget);
	void __fastcall AddPicture(System::Classes::TStream* Source, unsigned aType, System::AnsiString aMime, System::UnicodeString aDescription);
	void __fastcall DeletePicture(TFlacPictureBlock* aFlacPictureBlock);
	System::UnicodeString __fastcall GetPropertyByFieldname(System::UnicodeString aField);
	bool __fastcall SetPropertyByFieldname(System::UnicodeString aField, System::UnicodeString aValue);
	void __fastcall GetAllFields(System::Classes::TStrings* Target);
	System::UnicodeString __fastcall GetPropertyByIndex(int aIndex);
	bool __fastcall SetPropertyByIndex(int aIndex, System::UnicodeString aValue);
};


//-- var, const, procedure ---------------------------------------------------
#define FLAC_MARKER L"fLaC"
extern DELPHI_PACKAGE Flacfiles__1 Picture_Types;
}	/* namespace Flacfiles */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FLACFILES)
using namespace Flacfiles;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// FlacfilesHPP
