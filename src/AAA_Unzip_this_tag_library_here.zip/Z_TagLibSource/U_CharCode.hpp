﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'U_CharCode.pas' rev: 34.00 (Windows)

#ifndef U_charcodeHPP
#define U_charcodeHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <Winapi.Windows.hpp>

//-- user supplied -----------------------------------------------------------

namespace U_charcode
{
//-- forward type declarations -----------------------------------------------
struct TCodePage;
struct TConvertOptions;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TCodePage
{
public:
	System::UnicodeString Description;
	unsigned CodePage;
	int Index;
};


struct DECLSPEC_DRECORD TConvertOptions
{
public:
	TCodePage Greek;
	TCodePage Cyrillic;
	TCodePage Hebrew;
	TCodePage Arabic;
	TCodePage Thai;
	TCodePage Korean;
	TCodePage Chinese;
	TCodePage Japanese;
	bool AutoDetectCodePage;
};


typedef System::StaticArray<TCodePage, 2> U_charcode__1;

typedef System::StaticArray<TCodePage, 3> U_charcode__2;

typedef System::StaticArray<TCodePage, 3> U_charcode__3;

typedef System::StaticArray<TCodePage, 3> U_charcode__4;

typedef System::StaticArray<TCodePage, 1> U_charcode__5;

typedef System::StaticArray<TCodePage, 2> U_charcode__6;

typedef System::StaticArray<TCodePage, 1> U_charcode__7;

typedef System::StaticArray<TCodePage, 1> U_charcode__8;

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE TCodePage DefaultCharCode;
extern DELPHI_PACKAGE U_charcode__1 GreekEncodings;
extern DELPHI_PACKAGE U_charcode__2 CyrillicEncodings;
extern DELPHI_PACKAGE U_charcode__3 HebrewEncodings;
extern DELPHI_PACKAGE U_charcode__4 ArabicEncodings;
extern DELPHI_PACKAGE U_charcode__5 ThaiEncodings;
extern DELPHI_PACKAGE U_charcode__6 ChineseEncodings;
extern DELPHI_PACKAGE U_charcode__7 KoreanEncodings;
extern DELPHI_PACKAGE U_charcode__8 JapaneseEncodings;
extern DELPHI_PACKAGE TCodePage __fastcall GetCodepage(System::UnicodeString aFilename, const TConvertOptions &Options)/* overload */;
extern DELPHI_PACKAGE TCodePage __fastcall GetCodepage(System::UnicodeString aFilename)/* overload */;
}	/* namespace U_charcode */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_U_CHARCODE)
using namespace U_charcode;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// U_charcodeHPP
