﻿// CodeGear C++Builder
// Copyright (c) 1995, 2021 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Apev2Tags.pas' rev: 34.00 (Windows)

#ifndef Apev2tagsHPP
#define Apev2tagsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <System.SysUtils.hpp>
#include <System.StrUtils.hpp>
#include <System.Variants.hpp>
#include <System.Contnrs.hpp>
#include <System.Classes.hpp>
#include <AudioFileBasics.hpp>
#include <Id3Basics.hpp>
#include <ApeTagItem.hpp>

//-- user supplied -----------------------------------------------------------

namespace Apev2tags
{
//-- forward type declarations -----------------------------------------------
struct TID3v1Structure;
struct TApeHeader;
class DELPHICLASS TBaseApeFile;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TID3v1Structure
{
public:
	System::StaticArray<char, 3> ID;
	System::StaticArray<char, 30> Title;
	System::StaticArray<char, 30> Artist;
	System::StaticArray<char, 30> Album;
	System::StaticArray<char, 4> Year;
	System::StaticArray<char, 30> Comment;
	System::Byte Genre;
};


struct DECLSPEC_DRECORD TApeHeader
{
public:
	System::StaticArray<char, 8> Preamble;
	unsigned Version;
	unsigned Size;
	unsigned ItemCount;
	unsigned Flags;
	System::StaticArray<System::Byte, 8> Reserved;
};


class PASCALIMPLEMENTATION TBaseApeFile : public Audiofilebasics::TBaseAudioFile
{
	typedef Audiofilebasics::TBaseAudioFile inherited;
	
private:
	TApeHeader fApev2TagFooter;
	TApeHeader fApev2TagHeader;
	TID3v1Structure fID3v1tag;
	bool fID3v1Present;
	unsigned fID3v1TagSize;
	unsigned fID3v2TagSize;
	unsigned fOffset;
	System::Contnrs::TObjectList* fItemList;
	bool __fastcall fIsValidHeader(const TApeHeader &aApeHeader);
	bool __fastcall fTagContainsHeader();
	System::UnicodeString __fastcall fGetComment();
	System::UnicodeString __fastcall fGetSubTitle();
	System::UnicodeString __fastcall fGetDebutAlbum();
	System::UnicodeString __fastcall fGetPublisher();
	System::UnicodeString __fastcall fGetConductor();
	System::UnicodeString __fastcall fGetComposer();
	System::UnicodeString __fastcall fGetCopyright();
	System::UnicodeString __fastcall fGetPublicationright();
	System::UnicodeString __fastcall fGetFile();
	System::UnicodeString __fastcall fGetEAN();
	System::UnicodeString __fastcall fGetISBN();
	System::UnicodeString __fastcall fGetCatalog();
	System::UnicodeString __fastcall fGetLC();
	System::UnicodeString __fastcall fGetRecordDate();
	System::UnicodeString __fastcall fGetRecordLocation();
	System::UnicodeString __fastcall fGetMedia();
	System::UnicodeString __fastcall fGetIndex();
	System::UnicodeString __fastcall fGetRelated();
	System::UnicodeString __fastcall fGetISRC();
	System::UnicodeString __fastcall fGetAbstract();
	System::UnicodeString __fastcall fGetLanguage();
	System::UnicodeString __fastcall fGetBibliography();
	System::UnicodeString __fastcall fGetIntroplay();
	void __fastcall fSetComment(System::UnicodeString aValue);
	void __fastcall fSetSubTitle(System::UnicodeString aValue);
	void __fastcall fSetDebutAlbum(System::UnicodeString aValue);
	void __fastcall fSetPublisher(System::UnicodeString aValue);
	void __fastcall fSetConductor(System::UnicodeString aValue);
	void __fastcall fSetComposer(System::UnicodeString aValue);
	void __fastcall fSetCopyright(System::UnicodeString aValue);
	void __fastcall fSetPublicationright(System::UnicodeString aValue);
	void __fastcall fSetFile(System::UnicodeString aValue);
	void __fastcall fSetEAN(System::UnicodeString aValue);
	void __fastcall fSetISBN(System::UnicodeString aValue);
	void __fastcall fSetCatalog(System::UnicodeString aValue);
	void __fastcall fSetLC(System::UnicodeString aValue);
	void __fastcall fSetRecordDate(System::UnicodeString aValue);
	void __fastcall fSetRecordLocation(System::UnicodeString aValue);
	void __fastcall fSetMedia(System::UnicodeString aValue);
	void __fastcall fSetIndex(System::UnicodeString aValue);
	void __fastcall fSetRelated(System::UnicodeString aValue);
	void __fastcall fSetISRC(System::UnicodeString aValue);
	void __fastcall fSetAbstract(System::UnicodeString aValue);
	void __fastcall fSetLanguage(System::UnicodeString aValue);
	void __fastcall fSetBibliography(System::UnicodeString aValue);
	void __fastcall fSetIntroplay(System::UnicodeString aValue);
	int __fastcall fComputeNewTagSize();
	unsigned __fastcall fGetTagSize();
	unsigned __fastcall fGetCombinedTagSize();
	void __fastcall fPrepareFooterAndHeader();
	bool __fastcall CheckForID3Tag(System::Classes::TStream* aStream);
	Audiofilebasics::TAudioError __fastcall ReadTagFromStream(System::Classes::TStream* aStream, bool ReadItems = true);
	
protected:
	virtual __int64 __fastcall fGetFileSize();
	virtual int __fastcall fGetDuration();
	virtual int __fastcall fGetBitrate();
	virtual int __fastcall fGetSamplerate();
	virtual int __fastcall fGetChannels();
	virtual bool __fastcall fGetValid();
	virtual void __fastcall fSetTitle(System::UnicodeString aValue);
	virtual void __fastcall fSetArtist(System::UnicodeString aValue);
	virtual void __fastcall fSetAlbum(System::UnicodeString aValue);
	virtual void __fastcall fSetYear(System::UnicodeString aValue);
	virtual void __fastcall fSetTrack(System::UnicodeString aValue);
	virtual void __fastcall fSetGenre(System::UnicodeString aValue);
	virtual System::UnicodeString __fastcall fGetTitle();
	virtual System::UnicodeString __fastcall fGetArtist();
	virtual System::UnicodeString __fastcall fGetAlbum();
	virtual System::UnicodeString __fastcall fGetYear();
	virtual System::UnicodeString __fastcall fGetTrack();
	virtual System::UnicodeString __fastcall fGetGenre();
	virtual bool __fastcall ReadAudioDataFromStream(System::Classes::TStream* aStream);
	
public:
	__property bool ContainsHeader = {read=fTagContainsHeader, nodefault};
	__property bool ID3v1Present = {read=fID3v1Present, nodefault};
	__property unsigned Apev2TagSize = {read=fGetTagSize, nodefault};
	__property unsigned ID3v1TagSize = {read=fID3v1TagSize, nodefault};
	__property unsigned ID3v2TagSize = {read=fID3v2TagSize, nodefault};
	__property unsigned CombinedTagSize = {read=fGetCombinedTagSize, nodefault};
	__property System::UnicodeString Comment = {read=fGetComment, write=fSetComment};
	__property System::UnicodeString SubTitle = {read=fGetSubTitle, write=fSetSubTitle};
	__property System::UnicodeString DebutAlbum = {read=fGetDebutAlbum, write=fSetDebutAlbum};
	__property System::UnicodeString Publisher = {read=fGetPublisher, write=fSetPublisher};
	__property System::UnicodeString Conductor = {read=fGetConductor, write=fSetConductor};
	__property System::UnicodeString Composer = {read=fGetComposer, write=fSetComposer};
	__property System::UnicodeString Copyright = {read=fGetCopyright, write=fSetCopyright};
	__property System::UnicodeString PublicationRight = {read=fGetPublicationright, write=fSetPublicationright};
	__property System::UnicodeString FileLocation = {read=fGetFile, write=fSetFile};
	__property System::UnicodeString EAN = {read=fGetEAN, write=fSetEAN};
	__property System::UnicodeString ISBN = {read=fGetISBN, write=fSetISBN};
	__property System::UnicodeString Catalog = {read=fGetCatalog, write=fSetCatalog};
	__property System::UnicodeString LabelCode = {read=fGetLC, write=fSetLC};
	__property System::UnicodeString RecordDate = {read=fGetRecordDate, write=fSetRecordDate};
	__property System::UnicodeString RecordLocation = {read=fGetRecordLocation, write=fSetRecordLocation};
	__property System::UnicodeString Media = {read=fGetMedia, write=fSetMedia};
	__property System::UnicodeString Indexes = {read=fGetIndex, write=fSetIndex};
	__property System::UnicodeString Related = {read=fGetRelated, write=fSetRelated};
	__property System::UnicodeString ISRC = {read=fGetISRC, write=fSetISRC};
	__property System::UnicodeString AbstractOfContent = {read=fGetAbstract, write=fSetAbstract};
	__property System::UnicodeString Language = {read=fGetLanguage, write=fSetLanguage};
	__property System::UnicodeString Bibliography = {read=fGetBibliography, write=fSetBibliography};
	__property System::UnicodeString Introplay = {read=fGetIntroplay, write=fSetIntroplay};
	__fastcall TBaseApeFile();
	__fastcall virtual ~TBaseApeFile();
	void __fastcall Clear();
	System::UnicodeString __fastcall GetValueByKey(System::AnsiString aKey);
	void __fastcall SetValueByKey(System::AnsiString aKey, System::UnicodeString aValue);
	bool __fastcall GetBinaryDataByKey(System::AnsiString aKey, System::Classes::TStream* dest);
	void __fastcall SetBinaryByKey(System::AnsiString aKey, System::Classes::TStream* source);
	void __fastcall GetAllFrames(System::Classes::TStrings* dest);
	bool __fastcall GetPicture(Apetagitem::TApePictureTypes aType, System::Classes::TStream* dest, System::UnicodeString &description)/* overload */;
	bool __fastcall GetPicture(System::AnsiString aKey, System::Classes::TStream* dest, System::UnicodeString &description)/* overload */;
	void __fastcall SetPicture(Apetagitem::TApePictureTypes aType, System::UnicodeString description, System::Classes::TStream* source)/* overload */;
	void __fastcall SetPicture(System::AnsiString aKey, System::UnicodeString description, System::Classes::TStream* source)/* overload */;
	void __fastcall GetAllPictureFrames(System::Classes::TStrings* dest);
	virtual Audiofilebasics::TAudioError __fastcall ReadFromFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall WriteToFile(System::UnicodeString aFilename);
	virtual Audiofilebasics::TAudioError __fastcall RemoveFromFile(System::UnicodeString aFilename);
};


//-- var, const, procedure ---------------------------------------------------
#define APE_PREAMBLE L"APETAGEX"
}	/* namespace Apev2tags */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_APEV2TAGS)
using namespace Apev2tags;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Apev2tagsHPP
