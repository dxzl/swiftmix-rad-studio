// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:21:31 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\WINDOWS\system32\wmpshell.dll (1)
// LIBID: {5CB42160-CD7C-4806-9367-1C4A65153F4A}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player Launcher
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// Errors:
//   Error creating palette bitmap of (TWMPPlayAsPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPPlayFolderAsPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPAddToPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPBurnAudioCDLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPSkinMngr) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "WMPLauncher_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmplauncher_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_WMPLauncher = {0x5CB42160, 0xCD7C, 0x4806,{ 0x93, 0x67, 0x1C,0x4A, 0x65, 0x15,0x3F, 0x4A} };
const GUID CLSID_WMPPlayAsPlaylistLauncher = {0xCE3FB1D1, 0x02AE, 0x4A5F,{ 0xA6, 0xE9, 0xD9,0xF1, 0xB4, 0x07,0x3E, 0x6C} };
const GUID CLSID_WMPPlayFolderAsPlaylistLauncher = {0x7D4734E6, 0x047E, 0x41E2,{ 0xAE, 0xAA, 0xE7,0x63, 0xB4, 0x73,0x9D, 0xC4} };
const GUID CLSID_WMPAddToPlaylistLauncher = {0xF1B9284F, 0xE9DC, 0x4E68,{ 0x9D, 0x7E, 0x42,0x36, 0x2A, 0x59,0xF0, 0xFD} };
const GUID CLSID_WMPBurnAudioCDLauncher = {0x8DD448E6, 0xC188, 0x4AED,{ 0xAF, 0x92, 0x44,0x95, 0x61, 0x94,0xEB, 0x1F} };
const GUID CLSID_WMPSkinMngr = {0xB2A7FD52, 0x301F, 0x4348,{ 0xB9, 0x3A, 0x63,0x8C, 0x6D, 0xE4,0x92, 0x29} };
const GUID IID_IWMPSkinManager = {0x076F2FA6, 0xED30, 0x448B,{ 0x8C, 0xC5, 0x3F,0x3E, 0xF3, 0x52,0x9C, 0x7A} };

};     // namespace Wmplauncher_tlb
