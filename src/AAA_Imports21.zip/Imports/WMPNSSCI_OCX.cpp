// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:20:37 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Program Files (x86)\Windows Media Player\wmpnssci.dll (1)
// LIBID: {453E9E02-8BA4-474C-BFA0-37727E44F6AE}
// LCID: 0
// Helpfile: 
// HelpString: Microsoft Windows Media Player Network Sharing Service Control Interface Library v1.0
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include <Vcl.OleCtrls.hpp>
#include <Vcl.OleServer.hpp>
#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#pragma option -w-8122
#include "WMPNSSCI_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmpnssci_tlb
{

INSSPropertyPtr& TProperty::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TProperty::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TProperty::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TProperty::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TProperty::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TProperty::ConnectTo(INSSPropertyPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TProperty::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_Property;
  sd.IntfIID = __uuidof(INSSProperty);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

BSTR __fastcall TProperty::get_Name(void)
{
  BSTR pbstrResult = 0;
  OLECHECK(GetDefaultInterface()->get_Name((BSTR*)&pbstrResult));
  return pbstrResult;
}

VARIANT __fastcall TProperty::get_Value(void)
{
  VARIANT pvResult;
  OLECHECK(GetDefaultInterface()->get_Value((VARIANT*)&pvResult));
  return pvResult;
}

INSSPropertiesPtr& TProperties::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TProperties::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TProperties::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TProperties::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TProperties::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TProperties::ConnectTo(INSSPropertiesPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TProperties::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_Properties;
  sd.IntfIID = __uuidof(INSSProperties);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

Wmpnssci_tlb::INSSProperty* __fastcall TProperties::GetProperty(BSTR Name/*[in]*/)
{
  Wmpnssci_tlb::INSSProperty* ppResult = 0;
  OLECHECK(GetDefaultInterface()->GetProperty(Name, (Wmpnssci_tlb::INSSProperty**)&ppResult));
  return ppResult;
}

Wmpnssci_tlb::INSSProperty* __fastcall TProperties::get_Item(long Index/*[in]*/)
{
  Wmpnssci_tlb::INSSProperty* ppResult = 0;
  OLECHECK(GetDefaultInterface()->get_Item(Index, (Wmpnssci_tlb::INSSProperty**)&ppResult));
  return ppResult;
}

long __fastcall TProperties::get_Count(void)
{
  long plResult;
  OLECHECK(GetDefaultInterface()->get_Count((long*)&plResult));
  return plResult;
}

INSSDevicePtr& TDevice::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TDevice::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TDevice::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TDevice::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TDevice::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TDevice::ConnectTo(INSSDevicePtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TDevice::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_Device;
  sd.IntfIID = __uuidof(INSSDevice);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

void __fastcall TDevice::ShowDevicePropertyPage(__int64 hWnd/*[in]*/)
{
  GetDefaultInterface()->ShowDevicePropertyPage(hWnd/*[in]*/);
}

BSTR __fastcall TDevice::get_MACAddress(void)
{
  BSTR pbstrResult = 0;
  OLECHECK(GetDefaultInterface()->get_MACAddress((BSTR*)&pbstrResult));
  return pbstrResult;
}

Wmpnssci_tlb::AuthorizationStatus __fastcall TDevice::get_Authorization(void)
{
  Wmpnssci_tlb::AuthorizationStatus peResult;
  OLECHECK(GetDefaultInterface()->get_Authorization((Wmpnssci_tlb::AuthorizationStatus*)&peResult));
  return peResult;
}

void __fastcall TDevice::set_Authorization(Wmpnssci_tlb::AuthorizationStatus peResult/*[in]*/)
{
  GetDefaultInterface()->set_Authorization(peResult/*[in]*/);
}

VARIANT_BOOL __fastcall TDevice::get_Disabled(void)
{
  VARIANT_BOOL pbResult;
  OLECHECK(GetDefaultInterface()->get_Disabled((VARIANT_BOOL*)&pbResult));
  return pbResult;
}

void __fastcall TDevice::set_Disabled(VARIANT_BOOL pbResult/*[in]*/)
{
  GetDefaultInterface()->set_Disabled(pbResult/*[in]*/);
}

Wmpnssci_tlb::INSSPropertiesPtr __fastcall TDevice::get_Properties(void)
{
  Wmpnssci_tlb::INSSPropertiesPtr ppResult;
  OLECHECK(GetDefaultInterface()->get_Properties(&ppResult));
  return ppResult;
}

INSSDevicesPtr& TDevices::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TDevices::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TDevices::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TDevices::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TDevices::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TDevices::ConnectTo(INSSDevicesPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TDevices::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_Devices;
  sd.IntfIID = __uuidof(INSSDevices);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

Wmpnssci_tlb::INSSDevice* __fastcall TDevices::GetDevice(BSTR MACAddress/*[in]*/)
{
  Wmpnssci_tlb::INSSDevice* ppResult = 0;
  OLECHECK(GetDefaultInterface()->GetDevice(MACAddress, (Wmpnssci_tlb::INSSDevice**)&ppResult));
  return ppResult;
}

Wmpnssci_tlb::INSSDevice* __fastcall TDevices::get_Item(long Index/*[in]*/)
{
  Wmpnssci_tlb::INSSDevice* ppResult = 0;
  OLECHECK(GetDefaultInterface()->get_Item(Index, (Wmpnssci_tlb::INSSDevice**)&ppResult));
  return ppResult;
}

long __fastcall TDevices::get_Count(void)
{
  long plResult;
  OLECHECK(GetDefaultInterface()->get_Count((long*)&plResult));
  return plResult;
}

INSSManagerPtr& TNSSManager::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TNSSManager::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TNSSManager::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TNSSManager::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TNSSManager::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TNSSManager::ConnectTo(INSSManagerPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TNSSManager::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_NSSManager;
  sd.IntfIID = __uuidof(INSSManager);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

void __fastcall TNSSManager::InitializeLibrarySharing(BSTR UserSID/*[in,def,opt]*/)
{
  GetDefaultInterface()->InitializeLibrarySharing(UserSID/*[in,def,opt]*/);
}

Wmpnssci_tlb::INSSDevices* __fastcall TNSSManager::GetAllDevices(void)
{
  Wmpnssci_tlb::INSSDevices* ppResult = 0;
  OLECHECK(GetDefaultInterface()->GetAllDevices((Wmpnssci_tlb::INSSDevices**)&ppResult));
  return ppResult;
}

Wmpnssci_tlb::INSSDevices* __fastcall TNSSManager::GetDevices(Wmpnssci_tlb::AuthorizationStatus Authorization/*[in]*/)
{
  Wmpnssci_tlb::INSSDevices* ppResult = 0;
  OLECHECK(GetDefaultInterface()->GetDevices(Authorization, (Wmpnssci_tlb::INSSDevices**)&ppResult));
  return ppResult;
}

void __fastcall TNSSManager::RemoveDevice(BSTR MACAddress/*[in]*/)
{
  GetDefaultInterface()->RemoveDevice(MACAddress/*[in]*/);
}

BSTR __fastcall TNSSManager::Advise(LPUNKNOWN DeviceNotify/*[in]*/)
{
  BSTR pbstrResult = 0;
  OLECHECK(GetDefaultInterface()->Advise(DeviceNotify, (BSTR*)&pbstrResult));
  return pbstrResult;
}

void __fastcall TNSSManager::Unadvise(BSTR Cookie/*[in]*/)
{
  GetDefaultInterface()->Unadvise(Cookie/*[in]*/);
}

VARIANT_BOOL __fastcall TNSSManager::get_AllowByDefault(void)
{
  VARIANT_BOOL pbResult;
  OLECHECK(GetDefaultInterface()->get_AllowByDefault((VARIANT_BOOL*)&pbResult));
  return pbResult;
}

void __fastcall TNSSManager::set_AllowByDefault(VARIANT_BOOL pbResult/*[in]*/)
{
  GetDefaultInterface()->set_AllowByDefault(pbResult/*[in]*/);
}

Wmpnssci_tlb::ServiceStatus __fastcall TNSSManager::get_Status(void)
{
  Wmpnssci_tlb::ServiceStatus peResult;
  OLECHECK(GetDefaultInterface()->get_Status((Wmpnssci_tlb::ServiceStatus*)&peResult));
  return peResult;
}


};     // namespace Wmpnssci_tlb


// *********************************************************************//
// The Register function is invoked by the IDE when this module is 
// installed in a Package. It provides the list of Components (including
// OCXes) implemented by this module. The following implementation
// informs the IDE of the OCX proxy classes implemented here.
// *********************************************************************//
namespace Wmpnssci_ocx
{

void __fastcall PACKAGE Register()
{
  // [5]
  System::Classes::TComponentClass cls_svr[] = {
                              __classid(Wmpnssci_tlb::TProperty), 
                              __classid(Wmpnssci_tlb::TProperties), 
                              __classid(Wmpnssci_tlb::TDevice), 
                              __classid(Wmpnssci_tlb::TDevices), 
                              __classid(Wmpnssci_tlb::TNSSManager)
                           };
  System::Classes::RegisterComponents("ActiveX", cls_svr,
                     sizeof(cls_svr)/sizeof(cls_svr[0])-1);
}

};     // namespace Wmpnssci_ocx
