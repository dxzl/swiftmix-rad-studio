// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:19:41 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Windows\System32\wmpdxm.dll (1)
// LIBID: {73F0DD5C-D071-46B6-A8BF-897C84EAAC49}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player Compatibility Layer
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "WMPDXMLib_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmpdxmlib_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_WMPDXMLib = {0x73F0DD5C, 0xD071, 0x46B6,{ 0xA8, 0xBF, 0x89,0x7C, 0x84, 0xEA,0xAC, 0x49} };
const GUID IID_IWMPDXM = {0x5EAEE12F, 0x333C, 0x45F6,{ 0x97, 0x99, 0x24,0xDD, 0xC1, 0x2E,0xBE, 0xF3} };
const GUID IID_IWMPEmbed = {0x47C41E8A, 0x34B2, 0x417C,{ 0x9C, 0xF2, 0x09,0x73, 0x1F, 0xA2,0x98, 0xB6} };

};     // namespace Wmpdxmlib_tlb
