// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:18:47 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Windows\System32\msdxm.tlb (1)
// LIBID: {22D6F304-B0F6-11D0-94AB-0080C74C7E95}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// Errors:
//   Hint: TypeInfo 'MediaPlayer' changed to 'MediaPlayer_'
//   Hint: Symbol 'Click' renamed to '_Click'
//   Error creating palette bitmap of (TMediaPlayer) : Server C:\Windows\SysWOW64\wmpdxm.dll contains no icons
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include <Vcl.OleCtrls.hpp>
#include <Vcl.OleServer.hpp>
#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#pragma option -w-8122
#include "MediaPlayer_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Mediaplayer_tlb
{

IMediaPlayer2Ptr& TMediaPlayer::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TMediaPlayer::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TMediaPlayer::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TMediaPlayer::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TMediaPlayer::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TMediaPlayer::ConnectTo(IMediaPlayer2Ptr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TMediaPlayer::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_MediaPlayer_;
  sd.IntfIID = __uuidof(IMediaPlayer2);
  sd.EventIID= __uuidof(_MediaPlayerEvents);
  ServerData = &sd;
}

void __fastcall TMediaPlayer::InvokeEvent(int id, Vcl::Oleserver::TVariantArray& params)
{
  switch(id)
  {
    case 1505: {
      if (OnDVDNotify) {
        (OnDVDNotify)(this, params[0], params[1], params[2]);
      }
      break;
      }
    case 3002: {
      if (OnEndOfStream) {
        (OnEndOfStream)(this, params[0]);
      }
      break;
      }
    case -602: {
      if (OnKeyDown) {
        (OnKeyDown)(this, params[0], params[1]);
      }
      break;
      }
    case -604: {
      if (OnKeyUp) {
        (OnKeyUp)(this, params[0], params[1]);
      }
      break;
      }
    case -603: {
      if (OnKeyPress) {
        (OnKeyPress)(this, params[0]);
      }
      break;
      }
    case -606: {
      if (OnMouseMove) {
        (OnMouseMove)(this, params[0], params[1], params[2], params[3]);
      }
      break;
      }
    case -605: {
      if (OnMouseDown) {
        (OnMouseDown)(this, params[0], params[1], params[2], params[3]);
      }
      break;
      }
    case -607: {
      if (OnMouseUp) {
        (OnMouseUp)(this, params[0], params[1], params[2], params[3]);
      }
      break;
      }
    case -600: {
      if (On_Click) {
        (On_Click)(this, params[0], params[1], params[2], params[3]);
      }
      break;
      }
    case -601: {
      if (OnDblClick) {
        (OnDblClick)(this, params[0], params[1], params[2], params[3]);
      }
      break;
      }
    case 3011: {
      if (OnOpenStateChange) {
        (OnOpenStateChange)(this, params[0], params[1]);
      }
      break;
      }
    case 3012: {
      if (OnPlayStateChange) {
        (OnPlayStateChange)(this, params[0], params[1]);
      }
      break;
      }
    case 3001: {
      if (OnScriptCommand) {
        (OnScriptCommand)(this, params[0].bstrVal, params[1].bstrVal);
      }
      break;
      }
    case 3003: {
      if (OnBuffering) {
        (OnBuffering)(this, params[0]);
      }
      break;
      }
    case 3010: {
      if (OnError) {
        (OnError)(this);
      }
      break;
      }
    case 3006: {
      if (OnMarkerHit) {
        (OnMarkerHit)(this, params[0]);
      }
      break;
      }
    case 3009: {
      if (OnWarning) {
        (OnWarning)(this, params[0], params[1], params[2].bstrVal);
      }
      break;
      }
    case 3008: {
      if (OnNewStream) {
        (OnNewStream)(this);
      }
      break;
      }
    case 3004: {
      if (OnDisconnect) {
        (OnDisconnect)(this, params[0]);
      }
      break;
      }
    case -609: {
      if (OnReadyStateChange) {
        (OnReadyStateChange)(this, (Mediaplayer_tlb::MPReadyStateConstants)(int)params[0]);
      }
      break;
      }
    default:
      break;
  }
}

void __fastcall TMediaPlayer::Play(void)
{
  GetDefaultInterface()->Play();
}

void __fastcall TMediaPlayer::Stop(void)
{
  GetDefaultInterface()->Stop();
}

void __fastcall TMediaPlayer::Pause(void)
{
  GetDefaultInterface()->Pause();
}

double __fastcall TMediaPlayer::GetMarkerTime(long MarkerNum/*[in]*/)
{
  double pMarkerTime;
  OLECHECK(GetDefaultInterface()->GetMarkerTime(MarkerNum, (double*)&pMarkerTime));
  return pMarkerTime;
}

BSTR __fastcall TMediaPlayer::GetMarkerName(long MarkerNum/*[in]*/)
{
  BSTR pbstrMarkerName = 0;
  OLECHECK(GetDefaultInterface()->GetMarkerName(MarkerNum, (BSTR*)&pbstrMarkerName));
  return pbstrMarkerName;
}

void __fastcall TMediaPlayer::AboutBox(void)
{
  GetDefaultInterface()->AboutBox();
}

VARIANT_BOOL __fastcall TMediaPlayer::GetCodecInstalled(long CodecNum/*[in]*/)
{
  VARIANT_BOOL pCodecInstalled;
  OLECHECK(GetDefaultInterface()->GetCodecInstalled(CodecNum, (VARIANT_BOOL*)&pCodecInstalled));
  return pCodecInstalled;
}

BSTR __fastcall TMediaPlayer::GetCodecDescription(long CodecNum/*[in]*/)
{
  BSTR pbstrCodecDescription = 0;
  OLECHECK(GetDefaultInterface()->GetCodecDescription(CodecNum, (BSTR*)&pbstrCodecDescription));
  return pbstrCodecDescription;
}

BSTR __fastcall TMediaPlayer::GetCodecURL(long CodecNum/*[in]*/)
{
  BSTR pbstrCodecURL = 0;
  OLECHECK(GetDefaultInterface()->GetCodecURL(CodecNum, (BSTR*)&pbstrCodecURL));
  return pbstrCodecURL;
}

BSTR __fastcall TMediaPlayer::GetMoreInfoURL(Mediaplayer_tlb::MPMoreInfoType MoreInfoType/*[in]*/)
{
  BSTR pbstrMoreInfoURL = 0;
  OLECHECK(GetDefaultInterface()->GetMoreInfoURL(MoreInfoType, (BSTR*)&pbstrMoreInfoURL));
  return pbstrMoreInfoURL;
}

BSTR __fastcall TMediaPlayer::GetMediaInfoString(Mediaplayer_tlb::MPMediaInfoType MediaInfoType/*[in]*/)
{
  BSTR pbstrMediaInfo = 0;
  OLECHECK(GetDefaultInterface()->GetMediaInfoString(MediaInfoType, (BSTR*)&pbstrMediaInfo));
  return pbstrMediaInfo;
}

void __fastcall TMediaPlayer::Cancel(void)
{
  GetDefaultInterface()->Cancel();
}

void __fastcall TMediaPlayer::Open(BSTR bstrFileName/*[in]*/)
{
  GetDefaultInterface()->Open(bstrFileName/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::IsSoundCardEnabled(void)
{
  VARIANT_BOOL pbSoundCard;
  OLECHECK(GetDefaultInterface()->IsSoundCardEnabled((VARIANT_BOOL*)&pbSoundCard));
  return pbSoundCard;
}

void __fastcall TMediaPlayer::Next(void)
{
  GetDefaultInterface()->Next();
}

void __fastcall TMediaPlayer::Previous(void)
{
  GetDefaultInterface()->Previous();
}

void __fastcall TMediaPlayer::StreamSelect(long StreamNum/*[in]*/)
{
  GetDefaultInterface()->StreamSelect(StreamNum/*[in]*/);
}

void __fastcall TMediaPlayer::FastForward(void)
{
  GetDefaultInterface()->FastForward();
}

void __fastcall TMediaPlayer::FastReverse(void)
{
  GetDefaultInterface()->FastReverse();
}

BSTR __fastcall TMediaPlayer::GetStreamName(long StreamNum/*[in]*/)
{
  BSTR pbstrStreamName = 0;
  OLECHECK(GetDefaultInterface()->GetStreamName(StreamNum, (BSTR*)&pbstrStreamName));
  return pbstrStreamName;
}

long __fastcall TMediaPlayer::GetStreamGroup(long StreamNum/*[in]*/)
{
  long pStreamGroup;
  OLECHECK(GetDefaultInterface()->GetStreamGroup(StreamNum, (long*)&pStreamGroup));
  return pStreamGroup;
}

VARIANT_BOOL __fastcall TMediaPlayer::GetStreamSelected(long StreamNum/*[in]*/)
{
  VARIANT_BOOL pStreamSelected;
  OLECHECK(GetDefaultInterface()->GetStreamSelected(StreamNum, (VARIANT_BOOL*)&pStreamSelected));
  return pStreamSelected;
}

BSTR __fastcall TMediaPlayer::GetMediaParameter(long EntryNum/*[in]*/, 
                                                BSTR bstrParameterName/*[in]*/)
{
  BSTR pbstrParameterValue = 0;
  OLECHECK(GetDefaultInterface()->GetMediaParameter(EntryNum, bstrParameterName, (BSTR*)&pbstrParameterValue));
  return pbstrParameterValue;
}

BSTR __fastcall TMediaPlayer::GetMediaParameterName(long EntryNum/*[in]*/, long Index/*[in]*/)
{
  BSTR pbstrParameterName = 0;
  OLECHECK(GetDefaultInterface()->GetMediaParameterName(EntryNum, Index, (BSTR*)&pbstrParameterName));
  return pbstrParameterName;
}

long __fastcall TMediaPlayer::GetCurrentEntry(void)
{
  long pEntryNumber;
  OLECHECK(GetDefaultInterface()->GetCurrentEntry((long*)&pEntryNumber));
  return pEntryNumber;
}

void __fastcall TMediaPlayer::SetCurrentEntry(long EntryNumber/*[in]*/)
{
  GetDefaultInterface()->SetCurrentEntry(EntryNumber/*[in]*/);
}

void __fastcall TMediaPlayer::ShowDialog(Mediaplayer_tlb::MPShowDialogConstants mpDialogIndex/*[in]*/)
{
  GetDefaultInterface()->ShowDialog(mpDialogIndex/*[in]*/);
}

double __fastcall TMediaPlayer::get_CurrentPosition(void)
{
  double pCurrentPosition;
  OLECHECK(GetDefaultInterface()->get_CurrentPosition((double*)&pCurrentPosition));
  return pCurrentPosition;
}

void __fastcall TMediaPlayer::set_CurrentPosition(double pCurrentPosition/*[in]*/)
{
  GetDefaultInterface()->set_CurrentPosition(pCurrentPosition/*[in]*/);
}

double __fastcall TMediaPlayer::get_Duration(void)
{
  double pDuration;
  OLECHECK(GetDefaultInterface()->get_Duration((double*)&pDuration));
  return pDuration;
}

long __fastcall TMediaPlayer::get_ImageSourceWidth(void)
{
  long pWidth;
  OLECHECK(GetDefaultInterface()->get_ImageSourceWidth((long*)&pWidth));
  return pWidth;
}

long __fastcall TMediaPlayer::get_ImageSourceHeight(void)
{
  long pHeight;
  OLECHECK(GetDefaultInterface()->get_ImageSourceHeight((long*)&pHeight));
  return pHeight;
}

long __fastcall TMediaPlayer::get_MarkerCount(void)
{
  long pMarkerCount;
  OLECHECK(GetDefaultInterface()->get_MarkerCount((long*)&pMarkerCount));
  return pMarkerCount;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_CanScan(void)
{
  VARIANT_BOOL pCanScan;
  OLECHECK(GetDefaultInterface()->get_CanScan((VARIANT_BOOL*)&pCanScan));
  return pCanScan;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_CanSeek(void)
{
  VARIANT_BOOL pCanSeek;
  OLECHECK(GetDefaultInterface()->get_CanSeek((VARIANT_BOOL*)&pCanSeek));
  return pCanSeek;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_CanSeekToMarkers(void)
{
  VARIANT_BOOL pCanSeekToMarkers;
  OLECHECK(GetDefaultInterface()->get_CanSeekToMarkers((VARIANT_BOOL*)&pCanSeekToMarkers));
  return pCanSeekToMarkers;
}

long __fastcall TMediaPlayer::get_CurrentMarker(void)
{
  long pCurrentMarker;
  OLECHECK(GetDefaultInterface()->get_CurrentMarker((long*)&pCurrentMarker));
  return pCurrentMarker;
}

void __fastcall TMediaPlayer::set_CurrentMarker(long pCurrentMarker/*[in]*/)
{
  GetDefaultInterface()->set_CurrentMarker(pCurrentMarker/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_FileName(void)
{
  BSTR pbstrFileName = 0;
  OLECHECK(GetDefaultInterface()->get_FileName((BSTR*)&pbstrFileName));
  return pbstrFileName;
}

void __fastcall TMediaPlayer::set_FileName(BSTR pbstrFileName/*[in]*/)
{
  GetDefaultInterface()->set_FileName(pbstrFileName/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_SourceLink(void)
{
  BSTR pbstrSourceLink = 0;
  OLECHECK(GetDefaultInterface()->get_SourceLink((BSTR*)&pbstrSourceLink));
  return pbstrSourceLink;
}

DATE __fastcall TMediaPlayer::get_CreationDate(void)
{
  DATE pCreationDate;
  OLECHECK(GetDefaultInterface()->get_CreationDate((DATE*)&pCreationDate));
  return pCreationDate;
}

BSTR __fastcall TMediaPlayer::get_ErrorCorrection(void)
{
  BSTR pbstrErrorCorrection = 0;
  OLECHECK(GetDefaultInterface()->get_ErrorCorrection((BSTR*)&pbstrErrorCorrection));
  return pbstrErrorCorrection;
}

long __fastcall TMediaPlayer::get_Bandwidth(void)
{
  long pBandwidth;
  OLECHECK(GetDefaultInterface()->get_Bandwidth((long*)&pBandwidth));
  return pBandwidth;
}

long __fastcall TMediaPlayer::get_SourceProtocol(void)
{
  long pSourceProtocol;
  OLECHECK(GetDefaultInterface()->get_SourceProtocol((long*)&pSourceProtocol));
  return pSourceProtocol;
}

long __fastcall TMediaPlayer::get_ReceivedPackets(void)
{
  long pReceivedPackets;
  OLECHECK(GetDefaultInterface()->get_ReceivedPackets((long*)&pReceivedPackets));
  return pReceivedPackets;
}

long __fastcall TMediaPlayer::get_RecoveredPackets(void)
{
  long pRecoveredPackets;
  OLECHECK(GetDefaultInterface()->get_RecoveredPackets((long*)&pRecoveredPackets));
  return pRecoveredPackets;
}

long __fastcall TMediaPlayer::get_LostPackets(void)
{
  long pLostPackets;
  OLECHECK(GetDefaultInterface()->get_LostPackets((long*)&pLostPackets));
  return pLostPackets;
}

long __fastcall TMediaPlayer::get_ReceptionQuality(void)
{
  long pReceptionQuality;
  OLECHECK(GetDefaultInterface()->get_ReceptionQuality((long*)&pReceptionQuality));
  return pReceptionQuality;
}

long __fastcall TMediaPlayer::get_BufferingCount(void)
{
  long pBufferingCount;
  OLECHECK(GetDefaultInterface()->get_BufferingCount((long*)&pBufferingCount));
  return pBufferingCount;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_IsBroadcast(void)
{
  VARIANT_BOOL pIsBroadcast;
  OLECHECK(GetDefaultInterface()->get_IsBroadcast((VARIANT_BOOL*)&pIsBroadcast));
  return pIsBroadcast;
}

long __fastcall TMediaPlayer::get_BufferingProgress(void)
{
  long pBufferingProgress;
  OLECHECK(GetDefaultInterface()->get_BufferingProgress((long*)&pBufferingProgress));
  return pBufferingProgress;
}

BSTR __fastcall TMediaPlayer::get_ChannelName(void)
{
  BSTR pbstrChannelName = 0;
  OLECHECK(GetDefaultInterface()->get_ChannelName((BSTR*)&pbstrChannelName));
  return pbstrChannelName;
}

BSTR __fastcall TMediaPlayer::get_ChannelDescription(void)
{
  BSTR pbstrChannelDescription = 0;
  OLECHECK(GetDefaultInterface()->get_ChannelDescription((BSTR*)&pbstrChannelDescription));
  return pbstrChannelDescription;
}

BSTR __fastcall TMediaPlayer::get_ChannelURL(void)
{
  BSTR pbstrChannelURL = 0;
  OLECHECK(GetDefaultInterface()->get_ChannelURL((BSTR*)&pbstrChannelURL));
  return pbstrChannelURL;
}

BSTR __fastcall TMediaPlayer::get_ContactAddress(void)
{
  BSTR pbstrContactAddress = 0;
  OLECHECK(GetDefaultInterface()->get_ContactAddress((BSTR*)&pbstrContactAddress));
  return pbstrContactAddress;
}

BSTR __fastcall TMediaPlayer::get_ContactPhone(void)
{
  BSTR pbstrContactPhone = 0;
  OLECHECK(GetDefaultInterface()->get_ContactPhone((BSTR*)&pbstrContactPhone));
  return pbstrContactPhone;
}

BSTR __fastcall TMediaPlayer::get_ContactEmail(void)
{
  BSTR pbstrContactEmail = 0;
  OLECHECK(GetDefaultInterface()->get_ContactEmail((BSTR*)&pbstrContactEmail));
  return pbstrContactEmail;
}

double __fastcall TMediaPlayer::get_BufferingTime(void)
{
  double pBufferingTime;
  OLECHECK(GetDefaultInterface()->get_BufferingTime((double*)&pBufferingTime));
  return pBufferingTime;
}

void __fastcall TMediaPlayer::set_BufferingTime(double pBufferingTime/*[in]*/)
{
  GetDefaultInterface()->set_BufferingTime(pBufferingTime/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AutoStart(void)
{
  VARIANT_BOOL pAutoStart;
  OLECHECK(GetDefaultInterface()->get_AutoStart((VARIANT_BOOL*)&pAutoStart));
  return pAutoStart;
}

void __fastcall TMediaPlayer::set_AutoStart(VARIANT_BOOL pAutoStart/*[in]*/)
{
  GetDefaultInterface()->set_AutoStart(pAutoStart/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AutoRewind(void)
{
  VARIANT_BOOL pAutoRewind;
  OLECHECK(GetDefaultInterface()->get_AutoRewind((VARIANT_BOOL*)&pAutoRewind));
  return pAutoRewind;
}

void __fastcall TMediaPlayer::set_AutoRewind(VARIANT_BOOL pAutoRewind/*[in]*/)
{
  GetDefaultInterface()->set_AutoRewind(pAutoRewind/*[in]*/);
}

double __fastcall TMediaPlayer::get_Rate(void)
{
  double pRate;
  OLECHECK(GetDefaultInterface()->get_Rate((double*)&pRate));
  return pRate;
}

void __fastcall TMediaPlayer::set_Rate(double pRate/*[in]*/)
{
  GetDefaultInterface()->set_Rate(pRate/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendKeyboardEvents(void)
{
  VARIANT_BOOL pSendKeyboardEvents;
  OLECHECK(GetDefaultInterface()->get_SendKeyboardEvents((VARIANT_BOOL*)&pSendKeyboardEvents));
  return pSendKeyboardEvents;
}

void __fastcall TMediaPlayer::set_SendKeyboardEvents(VARIANT_BOOL pSendKeyboardEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendKeyboardEvents(pSendKeyboardEvents/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendMouseClickEvents(void)
{
  VARIANT_BOOL pSendMouseClickEvents;
  OLECHECK(GetDefaultInterface()->get_SendMouseClickEvents((VARIANT_BOOL*)&pSendMouseClickEvents));
  return pSendMouseClickEvents;
}

void __fastcall TMediaPlayer::set_SendMouseClickEvents(VARIANT_BOOL pSendMouseClickEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendMouseClickEvents(pSendMouseClickEvents/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendMouseMoveEvents(void)
{
  VARIANT_BOOL pSendMouseMoveEvents;
  OLECHECK(GetDefaultInterface()->get_SendMouseMoveEvents((VARIANT_BOOL*)&pSendMouseMoveEvents));
  return pSendMouseMoveEvents;
}

void __fastcall TMediaPlayer::set_SendMouseMoveEvents(VARIANT_BOOL pSendMouseMoveEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendMouseMoveEvents(pSendMouseMoveEvents/*[in]*/);
}

long __fastcall TMediaPlayer::get_PlayCount(void)
{
  long pPlayCount;
  OLECHECK(GetDefaultInterface()->get_PlayCount((long*)&pPlayCount));
  return pPlayCount;
}

void __fastcall TMediaPlayer::set_PlayCount(long pPlayCount/*[in]*/)
{
  GetDefaultInterface()->set_PlayCount(pPlayCount/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ClickToPlay(void)
{
  VARIANT_BOOL pClickToPlay;
  OLECHECK(GetDefaultInterface()->get_ClickToPlay((VARIANT_BOOL*)&pClickToPlay));
  return pClickToPlay;
}

void __fastcall TMediaPlayer::set_ClickToPlay(VARIANT_BOOL pClickToPlay/*[in]*/)
{
  GetDefaultInterface()->set_ClickToPlay(pClickToPlay/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AllowScan(void)
{
  VARIANT_BOOL pAllowScan;
  OLECHECK(GetDefaultInterface()->get_AllowScan((VARIANT_BOOL*)&pAllowScan));
  return pAllowScan;
}

void __fastcall TMediaPlayer::set_AllowScan(VARIANT_BOOL pAllowScan/*[in]*/)
{
  GetDefaultInterface()->set_AllowScan(pAllowScan/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_EnableContextMenu(void)
{
  VARIANT_BOOL pEnableContextMenu;
  OLECHECK(GetDefaultInterface()->get_EnableContextMenu((VARIANT_BOOL*)&pEnableContextMenu));
  return pEnableContextMenu;
}

void __fastcall TMediaPlayer::set_EnableContextMenu(VARIANT_BOOL pEnableContextMenu/*[in]*/)
{
  GetDefaultInterface()->set_EnableContextMenu(pEnableContextMenu/*[in]*/);
}

long __fastcall TMediaPlayer::get_CursorType(void)
{
  long pCursorType;
  OLECHECK(GetDefaultInterface()->get_CursorType((long*)&pCursorType));
  return pCursorType;
}

void __fastcall TMediaPlayer::set_CursorType(long pCursorType/*[in]*/)
{
  GetDefaultInterface()->set_CursorType(pCursorType/*[in]*/);
}

long __fastcall TMediaPlayer::get_CodecCount(void)
{
  long pCodecCount;
  OLECHECK(GetDefaultInterface()->get_CodecCount((long*)&pCodecCount));
  return pCodecCount;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AllowChangeDisplaySize(void)
{
  VARIANT_BOOL pAllowChangeDisplaySize;
  OLECHECK(GetDefaultInterface()->get_AllowChangeDisplaySize((VARIANT_BOOL*)&pAllowChangeDisplaySize));
  return pAllowChangeDisplaySize;
}

void __fastcall TMediaPlayer::set_AllowChangeDisplaySize(VARIANT_BOOL pAllowChangeDisplaySize/*[in]*/)
{
  GetDefaultInterface()->set_AllowChangeDisplaySize(pAllowChangeDisplaySize/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_IsDurationValid(void)
{
  VARIANT_BOOL pIsDurationValid;
  OLECHECK(GetDefaultInterface()->get_IsDurationValid((VARIANT_BOOL*)&pIsDurationValid));
  return pIsDurationValid;
}

long __fastcall TMediaPlayer::get_OpenState(void)
{
  long pOpenState;
  OLECHECK(GetDefaultInterface()->get_OpenState((long*)&pOpenState));
  return pOpenState;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendOpenStateChangeEvents(void)
{
  VARIANT_BOOL pSendOpenStateChangeEvents;
  OLECHECK(GetDefaultInterface()->get_SendOpenStateChangeEvents((VARIANT_BOOL*)&pSendOpenStateChangeEvents));
  return pSendOpenStateChangeEvents;
}

void __fastcall TMediaPlayer::set_SendOpenStateChangeEvents(VARIANT_BOOL pSendOpenStateChangeEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendOpenStateChangeEvents(pSendOpenStateChangeEvents/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendWarningEvents(void)
{
  VARIANT_BOOL pSendWarningEvents;
  OLECHECK(GetDefaultInterface()->get_SendWarningEvents((VARIANT_BOOL*)&pSendWarningEvents));
  return pSendWarningEvents;
}

void __fastcall TMediaPlayer::set_SendWarningEvents(VARIANT_BOOL pSendWarningEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendWarningEvents(pSendWarningEvents/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendErrorEvents(void)
{
  VARIANT_BOOL pSendErrorEvents;
  OLECHECK(GetDefaultInterface()->get_SendErrorEvents((VARIANT_BOOL*)&pSendErrorEvents));
  return pSendErrorEvents;
}

void __fastcall TMediaPlayer::set_SendErrorEvents(VARIANT_BOOL pSendErrorEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendErrorEvents(pSendErrorEvents/*[in]*/);
}

Mediaplayer_tlb::MPPlayStateConstants __fastcall TMediaPlayer::get_PlayState(void)
{
  Mediaplayer_tlb::MPPlayStateConstants pPlayState;
  OLECHECK(GetDefaultInterface()->get_PlayState((Mediaplayer_tlb::MPPlayStateConstants*)&pPlayState));
  return pPlayState;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_SendPlayStateChangeEvents(void)
{
  VARIANT_BOOL pSendPlayStateChangeEvents;
  OLECHECK(GetDefaultInterface()->get_SendPlayStateChangeEvents((VARIANT_BOOL*)&pSendPlayStateChangeEvents));
  return pSendPlayStateChangeEvents;
}

void __fastcall TMediaPlayer::set_SendPlayStateChangeEvents(VARIANT_BOOL pSendPlayStateChangeEvents/*[in]*/)
{
  GetDefaultInterface()->set_SendPlayStateChangeEvents(pSendPlayStateChangeEvents/*[in]*/);
}

Mediaplayer_tlb::MPDisplaySizeConstants __fastcall TMediaPlayer::get_DisplaySize(void)
{
  Mediaplayer_tlb::MPDisplaySizeConstants pDisplaySize;
  OLECHECK(GetDefaultInterface()->get_DisplaySize((Mediaplayer_tlb::MPDisplaySizeConstants*)&pDisplaySize));
  return pDisplaySize;
}

void __fastcall TMediaPlayer::set_DisplaySize(Mediaplayer_tlb::MPDisplaySizeConstants pDisplaySize/*[in]*/)
{
  GetDefaultInterface()->set_DisplaySize(pDisplaySize/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_InvokeURLs(void)
{
  VARIANT_BOOL pInvokeURLs;
  OLECHECK(GetDefaultInterface()->get_InvokeURLs((VARIANT_BOOL*)&pInvokeURLs));
  return pInvokeURLs;
}

void __fastcall TMediaPlayer::set_InvokeURLs(VARIANT_BOOL pInvokeURLs/*[in]*/)
{
  GetDefaultInterface()->set_InvokeURLs(pInvokeURLs/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_BaseURL(void)
{
  BSTR pbstrBaseURL = 0;
  OLECHECK(GetDefaultInterface()->get_BaseURL((BSTR*)&pbstrBaseURL));
  return pbstrBaseURL;
}

void __fastcall TMediaPlayer::set_BaseURL(BSTR pbstrBaseURL/*[in]*/)
{
  GetDefaultInterface()->set_BaseURL(pbstrBaseURL/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_DefaultFrame(void)
{
  BSTR pbstrDefaultFrame = 0;
  OLECHECK(GetDefaultInterface()->get_DefaultFrame((BSTR*)&pbstrDefaultFrame));
  return pbstrDefaultFrame;
}

void __fastcall TMediaPlayer::set_DefaultFrame(BSTR pbstrDefaultFrame/*[in]*/)
{
  GetDefaultInterface()->set_DefaultFrame(pbstrDefaultFrame/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_HasError(void)
{
  VARIANT_BOOL pHasError;
  OLECHECK(GetDefaultInterface()->get_HasError((VARIANT_BOOL*)&pHasError));
  return pHasError;
}

BSTR __fastcall TMediaPlayer::get_ErrorDescription(void)
{
  BSTR pbstrErrorDescription = 0;
  OLECHECK(GetDefaultInterface()->get_ErrorDescription((BSTR*)&pbstrErrorDescription));
  return pbstrErrorDescription;
}

long __fastcall TMediaPlayer::get_ErrorCode(void)
{
  long pErrorCode;
  OLECHECK(GetDefaultInterface()->get_ErrorCode((long*)&pErrorCode));
  return pErrorCode;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AnimationAtStart(void)
{
  VARIANT_BOOL pAnimationAtStart;
  OLECHECK(GetDefaultInterface()->get_AnimationAtStart((VARIANT_BOOL*)&pAnimationAtStart));
  return pAnimationAtStart;
}

void __fastcall TMediaPlayer::set_AnimationAtStart(VARIANT_BOOL pAnimationAtStart/*[in]*/)
{
  GetDefaultInterface()->set_AnimationAtStart(pAnimationAtStart/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_TransparentAtStart(void)
{
  VARIANT_BOOL pTransparentAtStart;
  OLECHECK(GetDefaultInterface()->get_TransparentAtStart((VARIANT_BOOL*)&pTransparentAtStart));
  return pTransparentAtStart;
}

void __fastcall TMediaPlayer::set_TransparentAtStart(VARIANT_BOOL pTransparentAtStart/*[in]*/)
{
  GetDefaultInterface()->set_TransparentAtStart(pTransparentAtStart/*[in]*/);
}

long __fastcall TMediaPlayer::get_Volume(void)
{
  long pVolume;
  OLECHECK(GetDefaultInterface()->get_Volume((long*)&pVolume));
  return pVolume;
}

void __fastcall TMediaPlayer::set_Volume(long pVolume/*[in]*/)
{
  GetDefaultInterface()->set_Volume(pVolume/*[in]*/);
}

long __fastcall TMediaPlayer::get_Balance(void)
{
  long pBalance;
  OLECHECK(GetDefaultInterface()->get_Balance((long*)&pBalance));
  return pBalance;
}

void __fastcall TMediaPlayer::set_Balance(long pBalance/*[in]*/)
{
  GetDefaultInterface()->set_Balance(pBalance/*[in]*/);
}

Mediaplayer_tlb::MPReadyStateConstants __fastcall TMediaPlayer::get_ReadyState(void)
{
  Mediaplayer_tlb::MPReadyStateConstants pValue;
  OLECHECK(GetDefaultInterface()->get_ReadyState((Mediaplayer_tlb::MPReadyStateConstants*)&pValue));
  return pValue;
}

double __fastcall TMediaPlayer::get_SelectionStart(void)
{
  double pValue;
  OLECHECK(GetDefaultInterface()->get_SelectionStart((double*)&pValue));
  return pValue;
}

void __fastcall TMediaPlayer::set_SelectionStart(double pValue/*[in]*/)
{
  GetDefaultInterface()->set_SelectionStart(pValue/*[in]*/);
}

double __fastcall TMediaPlayer::get_SelectionEnd(void)
{
  double pValue;
  OLECHECK(GetDefaultInterface()->get_SelectionEnd((double*)&pValue));
  return pValue;
}

void __fastcall TMediaPlayer::set_SelectionEnd(double pValue/*[in]*/)
{
  GetDefaultInterface()->set_SelectionEnd(pValue/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowDisplay(void)
{
  VARIANT_BOOL Show;
  OLECHECK(GetDefaultInterface()->get_ShowDisplay((VARIANT_BOOL*)&Show));
  return Show;
}

void __fastcall TMediaPlayer::set_ShowDisplay(VARIANT_BOOL Show/*[in]*/)
{
  GetDefaultInterface()->set_ShowDisplay(Show/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowControls(void)
{
  VARIANT_BOOL Show;
  OLECHECK(GetDefaultInterface()->get_ShowControls((VARIANT_BOOL*)&Show));
  return Show;
}

void __fastcall TMediaPlayer::set_ShowControls(VARIANT_BOOL Show/*[in]*/)
{
  GetDefaultInterface()->set_ShowControls(Show/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowPositionControls(void)
{
  VARIANT_BOOL Show;
  OLECHECK(GetDefaultInterface()->get_ShowPositionControls((VARIANT_BOOL*)&Show));
  return Show;
}

void __fastcall TMediaPlayer::set_ShowPositionControls(VARIANT_BOOL Show/*[in]*/)
{
  GetDefaultInterface()->set_ShowPositionControls(Show/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowTracker(void)
{
  VARIANT_BOOL Show;
  OLECHECK(GetDefaultInterface()->get_ShowTracker((VARIANT_BOOL*)&Show));
  return Show;
}

void __fastcall TMediaPlayer::set_ShowTracker(VARIANT_BOOL Show/*[in]*/)
{
  GetDefaultInterface()->set_ShowTracker(Show/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_EnablePositionControls(void)
{
  VARIANT_BOOL Enable;
  OLECHECK(GetDefaultInterface()->get_EnablePositionControls((VARIANT_BOOL*)&Enable));
  return Enable;
}

void __fastcall TMediaPlayer::set_EnablePositionControls(VARIANT_BOOL Enable/*[in]*/)
{
  GetDefaultInterface()->set_EnablePositionControls(Enable/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_EnableTracker(void)
{
  VARIANT_BOOL Enable;
  OLECHECK(GetDefaultInterface()->get_EnableTracker((VARIANT_BOOL*)&Enable));
  return Enable;
}

void __fastcall TMediaPlayer::set_EnableTracker(VARIANT_BOOL Enable/*[in]*/)
{
  GetDefaultInterface()->set_EnableTracker(Enable/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_Enabled(void)
{
  VARIANT_BOOL pEnabled;
  OLECHECK(GetDefaultInterface()->get_Enabled((VARIANT_BOOL*)&pEnabled));
  return pEnabled;
}

void __fastcall TMediaPlayer::set_Enabled(VARIANT_BOOL pEnabled/*[in]*/)
{
  GetDefaultInterface()->set_Enabled(pEnabled/*[in]*/);
}

::OLE_COLOR __fastcall TMediaPlayer::get_DisplayForeColor(void)
{
  ::OLE_COLOR ForeColor;
  OLECHECK(GetDefaultInterface()->get_DisplayForeColor((::OLE_COLOR*)&ForeColor));
  return ForeColor;
}

void __fastcall TMediaPlayer::set_DisplayForeColor(::OLE_COLOR ForeColor/*[in]*/)
{
  GetDefaultInterface()->set_DisplayForeColor(ForeColor/*[in]*/);
}

::OLE_COLOR __fastcall TMediaPlayer::get_DisplayBackColor(void)
{
  ::OLE_COLOR BackColor;
  OLECHECK(GetDefaultInterface()->get_DisplayBackColor((::OLE_COLOR*)&BackColor));
  return BackColor;
}

void __fastcall TMediaPlayer::set_DisplayBackColor(::OLE_COLOR BackColor/*[in]*/)
{
  GetDefaultInterface()->set_DisplayBackColor(BackColor/*[in]*/);
}

Mediaplayer_tlb::MPDisplayModeConstants __fastcall TMediaPlayer::get_DisplayMode(void)
{
  Mediaplayer_tlb::MPDisplayModeConstants pValue;
  OLECHECK(GetDefaultInterface()->get_DisplayMode((Mediaplayer_tlb::MPDisplayModeConstants*)&pValue));
  return pValue;
}

void __fastcall TMediaPlayer::set_DisplayMode(Mediaplayer_tlb::MPDisplayModeConstants pValue/*[in]*/)
{
  GetDefaultInterface()->set_DisplayMode(pValue/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_VideoBorder3D(void)
{
  VARIANT_BOOL pVideoBorderWidth;
  OLECHECK(GetDefaultInterface()->get_VideoBorder3D((VARIANT_BOOL*)&pVideoBorderWidth));
  return pVideoBorderWidth;
}

void __fastcall TMediaPlayer::set_VideoBorder3D(VARIANT_BOOL pVideoBorderWidth/*[in]*/)
{
  GetDefaultInterface()->set_VideoBorder3D(pVideoBorderWidth/*[in]*/);
}

long __fastcall TMediaPlayer::get_VideoBorderWidth(void)
{
  long pVideoBorderWidth;
  OLECHECK(GetDefaultInterface()->get_VideoBorderWidth((long*)&pVideoBorderWidth));
  return pVideoBorderWidth;
}

void __fastcall TMediaPlayer::set_VideoBorderWidth(long pVideoBorderWidth/*[in]*/)
{
  GetDefaultInterface()->set_VideoBorderWidth(pVideoBorderWidth/*[in]*/);
}

::OLE_COLOR __fastcall TMediaPlayer::get_VideoBorderColor(void)
{
  ::OLE_COLOR pVideoBorderWidth;
  OLECHECK(GetDefaultInterface()->get_VideoBorderColor((::OLE_COLOR*)&pVideoBorderWidth));
  return pVideoBorderWidth;
}

void __fastcall TMediaPlayer::set_VideoBorderColor(::OLE_COLOR pVideoBorderWidth/*[in]*/)
{
  GetDefaultInterface()->set_VideoBorderColor(pVideoBorderWidth/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowGotoBar(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_ShowGotoBar((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_ShowGotoBar(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_ShowGotoBar(pbool/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowStatusBar(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_ShowStatusBar((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_ShowStatusBar(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_ShowStatusBar(pbool/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowCaptioning(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_ShowCaptioning((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_ShowCaptioning(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_ShowCaptioning(pbool/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_ShowAudioControls(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_ShowAudioControls((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_ShowAudioControls(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_ShowAudioControls(pbool/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_CaptioningID(void)
{
  BSTR pstrText = 0;
  OLECHECK(GetDefaultInterface()->get_CaptioningID((BSTR*)&pstrText));
  return pstrText;
}

void __fastcall TMediaPlayer::set_CaptioningID(BSTR pstrText/*[in]*/)
{
  GetDefaultInterface()->set_CaptioningID(pstrText/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_Mute(void)
{
  VARIANT_BOOL vbool;
  OLECHECK(GetDefaultInterface()->get_Mute((VARIANT_BOOL*)&vbool));
  return vbool;
}

void __fastcall TMediaPlayer::set_Mute(VARIANT_BOOL vbool/*[in]*/)
{
  GetDefaultInterface()->set_Mute(vbool/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_CanPreview(void)
{
  VARIANT_BOOL pCanPreview;
  OLECHECK(GetDefaultInterface()->get_CanPreview((VARIANT_BOOL*)&pCanPreview));
  return pCanPreview;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_PreviewMode(void)
{
  VARIANT_BOOL pPreviewMode;
  OLECHECK(GetDefaultInterface()->get_PreviewMode((VARIANT_BOOL*)&pPreviewMode));
  return pPreviewMode;
}

void __fastcall TMediaPlayer::set_PreviewMode(VARIANT_BOOL pPreviewMode/*[in]*/)
{
  GetDefaultInterface()->set_PreviewMode(pPreviewMode/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_HasMultipleItems(void)
{
  VARIANT_BOOL pHasMuliItems;
  OLECHECK(GetDefaultInterface()->get_HasMultipleItems((VARIANT_BOOL*)&pHasMuliItems));
  return pHasMuliItems;
}

long __fastcall TMediaPlayer::get_Language(void)
{
  long pLanguage;
  OLECHECK(GetDefaultInterface()->get_Language((long*)&pLanguage));
  return pLanguage;
}

void __fastcall TMediaPlayer::set_Language(long pLanguage/*[in]*/)
{
  GetDefaultInterface()->set_Language(pLanguage/*[in]*/);
}

long __fastcall TMediaPlayer::get_AudioStream(void)
{
  long pStream;
  OLECHECK(GetDefaultInterface()->get_AudioStream((long*)&pStream));
  return pStream;
}

void __fastcall TMediaPlayer::set_AudioStream(long pStream/*[in]*/)
{
  GetDefaultInterface()->set_AudioStream(pStream/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_SAMIStyle(void)
{
  BSTR pbstrStyle = 0;
  OLECHECK(GetDefaultInterface()->get_SAMIStyle((BSTR*)&pbstrStyle));
  return pbstrStyle;
}

void __fastcall TMediaPlayer::set_SAMIStyle(BSTR pbstrStyle/*[in]*/)
{
  GetDefaultInterface()->set_SAMIStyle(pbstrStyle/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_SAMILang(void)
{
  BSTR pbstrLang = 0;
  OLECHECK(GetDefaultInterface()->get_SAMILang((BSTR*)&pbstrLang));
  return pbstrLang;
}

void __fastcall TMediaPlayer::set_SAMILang(BSTR pbstrLang/*[in]*/)
{
  GetDefaultInterface()->set_SAMILang(pbstrLang/*[in]*/);
}

BSTR __fastcall TMediaPlayer::get_SAMIFileName(void)
{
  BSTR pbstrFileName = 0;
  OLECHECK(GetDefaultInterface()->get_SAMIFileName((BSTR*)&pbstrFileName));
  return pbstrFileName;
}

void __fastcall TMediaPlayer::set_SAMIFileName(BSTR pbstrFileName/*[in]*/)
{
  GetDefaultInterface()->set_SAMIFileName(pbstrFileName/*[in]*/);
}

long __fastcall TMediaPlayer::get_StreamCount(void)
{
  long pStreamCount;
  OLECHECK(GetDefaultInterface()->get_StreamCount((long*)&pStreamCount));
  return pStreamCount;
}

BSTR __fastcall TMediaPlayer::get_ClientId(void)
{
  BSTR pbstrClientId = 0;
  OLECHECK(GetDefaultInterface()->get_ClientId((BSTR*)&pbstrClientId));
  return pbstrClientId;
}

long __fastcall TMediaPlayer::get_ConnectionSpeed(void)
{
  long plConnectionSpeed;
  OLECHECK(GetDefaultInterface()->get_ConnectionSpeed((long*)&plConnectionSpeed));
  return plConnectionSpeed;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_AutoSize(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_AutoSize((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_AutoSize(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_AutoSize(pbool/*[in]*/);
}

VARIANT_BOOL __fastcall TMediaPlayer::get_EnableFullScreenControls(void)
{
  VARIANT_BOOL pbVal;
  OLECHECK(GetDefaultInterface()->get_EnableFullScreenControls((VARIANT_BOOL*)&pbVal));
  return pbVal;
}

void __fastcall TMediaPlayer::set_EnableFullScreenControls(VARIANT_BOOL pbVal/*[in]*/)
{
  GetDefaultInterface()->set_EnableFullScreenControls(pbVal/*[in]*/);
}

LPDISPATCH __fastcall TMediaPlayer::get_ActiveMovie(void)
{
  LPDISPATCH ppdispatch;
  OLECHECK(GetDefaultInterface()->get_ActiveMovie((LPDISPATCH*)&ppdispatch));
  return ppdispatch;
}

LPDISPATCH __fastcall TMediaPlayer::get_NSPlay(void)
{
  LPDISPATCH ppdispatch;
  OLECHECK(GetDefaultInterface()->get_NSPlay((LPDISPATCH*)&ppdispatch));
  return ppdispatch;
}

VARIANT_BOOL __fastcall TMediaPlayer::get_WindowlessVideo(void)
{
  VARIANT_BOOL pbool;
  OLECHECK(GetDefaultInterface()->get_WindowlessVideo((VARIANT_BOOL*)&pbool));
  return pbool;
}

void __fastcall TMediaPlayer::set_WindowlessVideo(VARIANT_BOOL pbool/*[in]*/)
{
  GetDefaultInterface()->set_WindowlessVideo(pbool/*[in]*/);
}

Mediaplayer_tlb::IMediaPlayerDvdPtr __fastcall TMediaPlayer::get_DVD(void)
{
  Mediaplayer_tlb::IMediaPlayerDvdPtr ppdispatch;
  OLECHECK(GetDefaultInterface()->get_DVD(&ppdispatch));
  return ppdispatch;
}

long __fastcall TMediaPlayer::get_EntryCount(void)
{
  long pNumberEntries;
  OLECHECK(GetDefaultInterface()->get_EntryCount((long*)&pNumberEntries));
  return pNumberEntries;
}


};     // namespace Mediaplayer_tlb


// *********************************************************************//
// The Register function is invoked by the IDE when this module is 
// installed in a Package. It provides the list of Components (including
// OCXes) implemented by this module. The following implementation
// informs the IDE of the OCX proxy classes implemented here.
// *********************************************************************//
namespace Mediaplayer_ocx
{

void __fastcall PACKAGE Register()
{
  // [1]
  System::Classes::TComponentClass cls_svr[] = {
                              __classid(Mediaplayer_tlb::TMediaPlayer)
                           };
  System::Classes::RegisterComponents("ActiveX", cls_svr,
                     sizeof(cls_svr)/sizeof(cls_svr[0])-1);
}

};     // namespace Mediaplayer_ocx
