// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:21:31 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\WINDOWS\system32\wmpshell.dll (1)
// LIBID: {5CB42160-CD7C-4806-9367-1C4A65153F4A}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player Launcher
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// Errors:
//   Error creating palette bitmap of (TWMPPlayAsPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPPlayFolderAsPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPAddToPlaylistLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPBurnAudioCDLauncher) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
//   Error creating palette bitmap of (TWMPSkinMngr) : Server C:\WINDOWS\system32\wmpshell.dll contains no icons
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include <Vcl.OleCtrls.hpp>
#include <Vcl.OleServer.hpp>
#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#pragma option -w-8122
#include "WMPLauncher_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmplauncher_tlb
{

IUnknownPtr& TWMPPlayAsPlaylistLauncher::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TWMPPlayAsPlaylistLauncher::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TWMPPlayAsPlaylistLauncher::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TWMPPlayAsPlaylistLauncher::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TWMPPlayAsPlaylistLauncher::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TWMPPlayAsPlaylistLauncher::ConnectTo(IUnknownPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TWMPPlayAsPlaylistLauncher::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_WMPPlayAsPlaylistLauncher;
  sd.IntfIID = __uuidof(IUnknown);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

IUnknownPtr& TWMPPlayFolderAsPlaylistLauncher::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TWMPPlayFolderAsPlaylistLauncher::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TWMPPlayFolderAsPlaylistLauncher::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TWMPPlayFolderAsPlaylistLauncher::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TWMPPlayFolderAsPlaylistLauncher::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TWMPPlayFolderAsPlaylistLauncher::ConnectTo(IUnknownPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TWMPPlayFolderAsPlaylistLauncher::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_WMPPlayFolderAsPlaylistLauncher;
  sd.IntfIID = __uuidof(IUnknown);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

IUnknownPtr& TWMPAddToPlaylistLauncher::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TWMPAddToPlaylistLauncher::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TWMPAddToPlaylistLauncher::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TWMPAddToPlaylistLauncher::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TWMPAddToPlaylistLauncher::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TWMPAddToPlaylistLauncher::ConnectTo(IUnknownPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TWMPAddToPlaylistLauncher::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_WMPAddToPlaylistLauncher;
  sd.IntfIID = __uuidof(IUnknown);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

IUnknownPtr& TWMPBurnAudioCDLauncher::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TWMPBurnAudioCDLauncher::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TWMPBurnAudioCDLauncher::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TWMPBurnAudioCDLauncher::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TWMPBurnAudioCDLauncher::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TWMPBurnAudioCDLauncher::ConnectTo(IUnknownPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TWMPBurnAudioCDLauncher::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_WMPBurnAudioCDLauncher;
  sd.IntfIID = __uuidof(IUnknown);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

IWMPSkinManagerPtr& TWMPSkinMngr::GetDefaultInterface()
{
  if (!m_DefaultIntf)
    Connect();
  return m_DefaultIntf;
}

_di_IUnknown __fastcall TWMPSkinMngr::GetDunk()
{
  _di_IUnknown diUnk;
  if (m_DefaultIntf) {
    IUnknownPtr punk = m_DefaultIntf;
    diUnk = LPUNKNOWN(punk);
  }
  return diUnk;
}

void __fastcall TWMPSkinMngr::Connect()
{
  if (!m_DefaultIntf) {
    _di_IUnknown punk = GetServer();
    m_DefaultIntf = punk;
    if (ServerData->EventIID != GUID_NULL)
      ConnectEvents(GetDunk());
  }
}

void __fastcall TWMPSkinMngr::Disconnect()
{
  if (m_DefaultIntf) {

    if (ServerData->EventIID != GUID_NULL)
      DisconnectEvents(GetDunk());
    m_DefaultIntf.Reset();
  }
}

void __fastcall TWMPSkinMngr::BeforeDestruction()
{
  Disconnect();
}

void __fastcall TWMPSkinMngr::ConnectTo(IWMPSkinManagerPtr intf)
{
  Disconnect();
  m_DefaultIntf = intf;
  if (ServerData->EventIID != GUID_NULL)
    ConnectEvents(GetDunk());
}

void __fastcall TWMPSkinMngr::InitServerData()
{
  static Vcl::Oleserver::TServerData sd;
  sd.ClassID = CLSID_WMPSkinMngr;
  sd.IntfIID = __uuidof(IWMPSkinManager);
  sd.EventIID= GUID_NULL;
  ServerData = &sd;
}

void __fastcall TWMPSkinMngr::SetVisualStyle(BSTR bstrPath/*[in]*/)
{
  GetDefaultInterface()->SetVisualStyle(bstrPath/*[in]*/);
}


};     // namespace Wmplauncher_tlb


// *********************************************************************//
// The Register function is invoked by the IDE when this module is 
// installed in a Package. It provides the list of Components (including
// OCXes) implemented by this module. The following implementation
// informs the IDE of the OCX proxy classes implemented here.
// *********************************************************************//
namespace Wmplauncher_ocx
{

void __fastcall PACKAGE Register()
{
  // [5]
  System::Classes::TComponentClass cls_svr[] = {
                              __classid(Wmplauncher_tlb::TWMPPlayAsPlaylistLauncher), 
                              __classid(Wmplauncher_tlb::TWMPPlayFolderAsPlaylistLauncher), 
                              __classid(Wmplauncher_tlb::TWMPAddToPlaylistLauncher), 
                              __classid(Wmplauncher_tlb::TWMPBurnAudioCDLauncher), 
                              __classid(Wmplauncher_tlb::TWMPSkinMngr)
                           };
  System::Classes::RegisterComponents("ActiveX", cls_svr,
                     sizeof(cls_svr)/sizeof(cls_svr[0])-1);
}

};     // namespace Wmplauncher_ocx
