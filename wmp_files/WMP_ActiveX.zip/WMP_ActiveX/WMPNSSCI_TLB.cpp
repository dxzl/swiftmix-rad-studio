// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:20:37 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Program Files (x86)\Windows Media Player\wmpnssci.dll (1)
// LIBID: {453E9E02-8BA4-474C-BFA0-37727E44F6AE}
// LCID: 0
// Helpfile: 
// HelpString: Microsoft Windows Media Player Network Sharing Service Control Interface Library v1.0
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "WMPNSSCI_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmpnssci_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_WMPNSSCI = {0x453E9E02, 0x8BA4, 0x474C,{ 0xBF, 0xA0, 0x37,0x72, 0x7E, 0x44,0xF6, 0xAE} };
const GUID IID_INSSProperty = {0xB27C1EAC, 0xB909, 0x462C,{ 0xA0, 0x51, 0xF8,0x5D, 0xA6, 0x3D,0x61, 0x6B} };
const GUID CLSID_Property = {0xFC434359, 0xAF3E, 0x4F09,{ 0x85, 0x2E, 0xB5,0xD3, 0x38, 0x4F,0x24, 0x1D} };
const GUID IID_INSSProperties = {0xDF2F700E, 0x48CC, 0x40CE,{ 0xBB, 0xF7, 0x73,0x18, 0x72, 0x86,0xC4, 0x2D} };
const GUID CLSID_Properties = {0xAD5D2BA9, 0xB6A0, 0x45B6,{ 0x9E, 0xD5, 0xB5,0x9B, 0x85, 0x80,0x6D, 0x56} };
const GUID IID_INSSDevice = {0x055B0E0E, 0x3113, 0x4CAE,{ 0x9E, 0xEE, 0x6E,0x63, 0x21, 0x1B,0xEE, 0x37} };
const GUID CLSID_Device = {0x86223118, 0xF443, 0x4F05,{ 0xB0, 0xCF, 0x89,0x63, 0xA1, 0x57,0x47, 0xA6} };
const GUID IID_INSSDevices = {0x73DE3C35, 0xFAF7, 0x4934,{ 0xB3, 0x37, 0xC2,0x60, 0xD5, 0x92,0x68, 0x58} };
const GUID CLSID_Devices = {0x6DE2D8B3, 0x50B2, 0x45B7,{ 0x9D, 0xE3, 0x08,0x25, 0xCE, 0x8B,0x7F, 0x2D} };
const GUID IID_INSSNotify = {0xADC0EDF5, 0xFE64, 0x48FF,{ 0xA7, 0x11, 0xCB,0x4A, 0xB0, 0xF5,0xC2, 0xCA} };
const GUID IID_INSSManager = {0x204F4950, 0x212A, 0x414F,{ 0x9B, 0x27, 0x73,0xBD, 0x87, 0x42,0x3F, 0x25} };
const GUID CLSID_NSSManager = {0x92498132, 0x4D1A, 0x4297,{ 0x9B, 0x78, 0x9E,0x2E, 0x4B, 0xA9,0x9C, 0x07} };

};     // namespace Wmpnssci_tlb
