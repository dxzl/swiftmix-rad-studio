// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:19:41 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Windows\System32\wmpdxm.dll (1)
// LIBID: {73F0DD5C-D071-46B6-A8BF-897C84EAAC49}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player Compatibility Layer
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include <Vcl.OleCtrls.hpp>
#include <Vcl.OleServer.hpp>
#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#pragma option -w-8122
#include "WMPDXMLib_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Wmpdxmlib_tlb
{


};     // namespace Wmpdxmlib_tlb
