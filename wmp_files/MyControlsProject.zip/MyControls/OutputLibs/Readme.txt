NOTE: After building, the output MyControls.bpl file is located in folder:

 \Users\Public\Public Documents\Embarcadero\Studio\22.0\BPL