// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// $Rev: 92848 $
// File generated on 3/31/2019 11:18:47 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\Windows\System32\msdxm.tlb (1)
// LIBID: {22D6F304-B0F6-11D0-94AB-0080C74C7E95}
// LCID: 0
// Helpfile: 
// HelpString: Windows Media Player
// DepndLst: 
//   (1) v2.0 stdole, (C:\Windows\SysWOW64\stdole2.tlb)
// SYS_KIND: SYS_WIN32
// Errors:
//   Hint: TypeInfo 'MediaPlayer' changed to 'MediaPlayer_'
//   Hint: Symbol 'Click' renamed to '_Click'
//   Error creating palette bitmap of (TMediaPlayer) : Server C:\Windows\SysWOW64\wmpdxm.dll contains no icons
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "MediaPlayer_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Mediaplayer_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_MediaPlayer = {0x22D6F304, 0xB0F6, 0x11D0,{ 0x94, 0xAB, 0x00,0x80, 0xC7, 0x4C,0x7E, 0x95} };
const GUID DIID__MediaPlayerEvents = {0x2D3A4C40, 0xE711, 0x11D0,{ 0x94, 0xAB, 0x00,0x80, 0xC7, 0x4C,0x7E, 0x95} };
const GUID CLSID_MediaPlayer_ = {0x22D6F312, 0xB0F6, 0x11D0,{ 0x94, 0xAB, 0x00,0x80, 0xC7, 0x4C,0x7E, 0x95} };
const GUID IID_IMediaPlayer2 = {0x20D4F5E0, 0x5475, 0x11D2,{ 0x97, 0x74, 0x00,0x00, 0xF8, 0x08,0x55, 0xE6} };
const GUID IID_IMediaPlayer = {0x22D6F311, 0xB0F6, 0x11D0,{ 0x94, 0xAB, 0x00,0x80, 0xC7, 0x4C,0x7E, 0x95} };
const GUID IID_IMediaPlayerDvd = {0x746EB440, 0x3835, 0x11D2,{ 0x97, 0x74, 0x00,0x00, 0xF8, 0x08,0x55, 0xE6} };

};     // namespace Mediaplayer_tlb
